import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, boolean, integer, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Farmer profiles
export const farmers = pgTable("farmers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  phone: text("phone").unique(),
  location: text("location"),
  farmSize: text("farm_size"),
  preferredLanguage: text("preferred_language").default("mr"), // Marathi by default
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  gpsAccuracy: decimal("gps_accuracy", { precision: 8, scale: 2 }),
  lastLocationUpdate: timestamp("last_location_update"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Crop history for farmers
export const cropHistory = pgTable("crop_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farmerId: varchar("farmer_id").notNull().references(() => farmers.id),
  cropName: text("crop_name").notNull(),
  season: text("season").notNull(),
  year: integer("year").notNull(),
  yield: text("yield"),
  issues: jsonb("issues"), // Store array of disease/pest issues
  createdAt: timestamp("created_at").defaultNow(),
});

// Chat conversations
export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farmerId: varchar("farmer_id").notNull().references(() => farmers.id),
  messages: jsonb("messages").notNull(), // Store array of messages
  topic: text("topic"), // weather, disease, market, general
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Agricultural knowledge base
export const knowledgeBase = pgTable("knowledge_base", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  category: text("category").notNull(), // crop, disease, weather, market
  title: text("title").notNull(),
  content: text("content").notNull(),
  contentMarathi: text("content_marathi"),
  keywords: text("keywords").array(), // For search
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Market rates
export const marketRates = pgTable("market_rates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  cropName: text("crop_name").notNull(),
  market: text("market").notNull(),
  pricePerUnit: text("price_per_unit").notNull(),
  unit: text("unit").notNull(),
  date: timestamp("date").notNull(),
  source: text("source"),
});

// Weather data
export const weatherData = pgTable("weather_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  location: text("location").notNull(),
  date: timestamp("date").notNull(),
  temperature: text("temperature"),
  humidity: text("humidity"),
  rainfall: text("rainfall"),
  windSpeed: text("wind_speed"),
  forecast: jsonb("forecast"), // Store forecast data
  alerts: jsonb("alerts"), // Store weather alerts
  source: text("source"), // 'accuweather', 'hyperlocal_ml', 'manual'
  airQuality: text("air_quality"),
  visibility: text("visibility"),
  pressure: text("pressure"),
  uvIndex: text("uv_index"),
  cloudCover: text("cloud_cover"),
  fogConditions: text("fog_conditions"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
});

// ML Predictions - Store results from various ML models
export const mlPredictions = pgTable("ml_predictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farmerId: varchar("farmer_id").notNull().references(() => farmers.id),
  modelType: text("model_type").notNull(), // 'hyperlocal_weather', 'market_rates', 'disease_detection', 'crop_health'
  inputData: jsonb("input_data").notNull(), // Store the input parameters
  prediction: jsonb("prediction").notNull(), // Store the ML model output
  confidence: decimal("confidence", { precision: 5, scale: 4 }), // Model confidence score
  modelVersion: text("model_version"),
  processingTime: integer("processing_time"), // Time taken for prediction in ms
  status: text("status").default("completed"), // 'pending', 'completed', 'failed'
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Plant Disease Detection Results
export const diseaseDetections = pgTable("disease_detections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farmerId: varchar("farmer_id").notNull().references(() => farmers.id),
  cropName: text("crop_name").notNull(),
  imageUrl: text("image_url"), // Stored image path/URL
  imageThumbnail: text("image_thumbnail"), // Compressed thumbnail
  detectedDiseases: jsonb("detected_diseases").notNull(), // Array of detected diseases with confidence
  recommendedTreatment: jsonb("recommended_treatment"), // Treatment suggestions
  severity: text("severity"), // 'low', 'medium', 'high', 'critical'
  confidence: decimal("confidence", { precision: 5, scale: 4 }),
  modelVersion: text("model_version"),
  verified: boolean("verified").default(false), // Expert verification status
  verifiedBy: text("verified_by"), // Expert who verified
  notes: text("notes"), // Additional notes from experts or farmer
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Farmer Query History with Intent Classification
export const queryHistory = pgTable("query_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farmerId: varchar("farmer_id").notNull().references(() => farmers.id),
  originalQuery: text("original_query").notNull(),
  detectedLanguage: text("detected_language"), // 'mr', 'en', 'hi', etc.
  transcribedText: text("transcribed_text"), // If from voice
  intent: text("intent").notNull(), // 'weather', 'disease', 'market', 'advisory', 'crop_health'
  subIntent: text("sub_intent"), // More specific intent
  entities: jsonb("entities"), // Extracted entities (crop names, locations, etc.)
  confidence: decimal("confidence", { precision: 5, scale: 4 }),
  response: text("response").notNull(),
  responseLanguage: text("response_language"),
  audioResponseUrl: text("audio_response_url"), // TTS audio file
  satisfied: boolean("satisfied"), // User feedback
  sessionId: varchar("session_id"), // Group related queries
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Market Rate Predictions
export const marketPredictions = pgTable("market_predictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farmerId: varchar("farmer_id").references(() => farmers.id),
  cropName: text("crop_name").notNull(),
  market: text("market").notNull(),
  currentPrice: decimal("current_price", { precision: 10, scale: 2 }),
  predictedPrices: jsonb("predicted_prices").notNull(), // Array of future price predictions
  predictionPeriod: text("prediction_period"), // '7d', '30d', '3m'
  factors: jsonb("factors"), // Factors affecting price
  confidence: decimal("confidence", { precision: 5, scale: 4 }),
  modelVersion: text("model_version"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Offline Sync Queue - Track data that needs syncing
export const offlineQueue = pgTable("offline_queue", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farmerId: varchar("farmer_id").notNull().references(() => farmers.id),
  operation: text("operation").notNull(), // 'create', 'update', 'delete'
  tableName: text("table_name").notNull(),
  recordId: varchar("record_id"),
  data: jsonb("data").notNull(),
  synced: boolean("synced").default(false),
  syncAttempts: integer("sync_attempts").default(0),
  lastSyncAttempt: timestamp("last_sync_attempt"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Government Schemes and Advisories
export const governmentSchemes = pgTable("government_schemes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  titleMarathi: text("title_marathi"),
  description: text("description").notNull(),
  descriptionMarathi: text("description_marathi"),
  eligibility: jsonb("eligibility"), // Eligibility criteria
  benefits: jsonb("benefits"), // Scheme benefits
  applicationProcess: text("application_process"),
  applicationProcessMarathi: text("application_process_marathi"),
  validFrom: timestamp("valid_from"),
  validTo: timestamp("valid_to"),
  targetCrops: text("target_crops").array(), // Applicable crops
  targetStates: text("target_states").array(), // Applicable states/regions
  schemeType: text("scheme_type"), // 'subsidy', 'insurance', 'loan', 'training'
  isActive: boolean("is_active").default(true),
  officialUrl: text("official_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Create insert schemas
export const insertFarmerSchema = createInsertSchema(farmers).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCropHistorySchema = createInsertSchema(cropHistory).omit({ id: true, createdAt: true });
export const insertConversationSchema = createInsertSchema(conversations).omit({ id: true, createdAt: true, updatedAt: true });
export const insertKnowledgeBaseSchema = createInsertSchema(knowledgeBase).omit({ id: true, createdAt: true });
export const insertMarketRateSchema = createInsertSchema(marketRates).omit({ id: true });
export const insertWeatherDataSchema = createInsertSchema(weatherData).omit({ id: true });
export const insertMlPredictionSchema = createInsertSchema(mlPredictions).omit({ id: true, createdAt: true });
export const insertDiseaseDetectionSchema = createInsertSchema(diseaseDetections).omit({ id: true, createdAt: true, updatedAt: true });
export const insertQueryHistorySchema = createInsertSchema(queryHistory).omit({ id: true, createdAt: true });
export const insertMarketPredictionSchema = createInsertSchema(marketPredictions).omit({ id: true, createdAt: true, lastUpdated: true });
export const insertOfflineQueueSchema = createInsertSchema(offlineQueue).omit({ id: true, createdAt: true });
export const insertGovernmentSchemeSchema = createInsertSchema(governmentSchemes).omit({ id: true, createdAt: true, updatedAt: true });

// Export types
export type Farmer = typeof farmers.$inferSelect;
export type InsertFarmer = z.infer<typeof insertFarmerSchema>;
export type CropHistory = typeof cropHistory.$inferSelect;
export type InsertCropHistory = z.infer<typeof insertCropHistorySchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type KnowledgeBase = typeof knowledgeBase.$inferSelect;
export type InsertKnowledgeBase = z.infer<typeof insertKnowledgeBaseSchema>;
export type MarketRate = typeof marketRates.$inferSelect;
export type InsertMarketRate = z.infer<typeof insertMarketRateSchema>;
export type WeatherData = typeof weatherData.$inferSelect;
export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;
export type MlPrediction = typeof mlPredictions.$inferSelect;
export type InsertMlPrediction = z.infer<typeof insertMlPredictionSchema>;
export type DiseaseDetection = typeof diseaseDetections.$inferSelect;
export type InsertDiseaseDetection = z.infer<typeof insertDiseaseDetectionSchema>;
export type QueryHistory = typeof queryHistory.$inferSelect;
export type InsertQueryHistory = z.infer<typeof insertQueryHistorySchema>;
export type MarketPrediction = typeof marketPredictions.$inferSelect;
export type InsertMarketPrediction = z.infer<typeof insertMarketPredictionSchema>;
export type OfflineQueue = typeof offlineQueue.$inferSelect;
export type InsertOfflineQueue = z.infer<typeof insertOfflineQueueSchema>;
export type GovernmentScheme = typeof governmentSchemes.$inferSelect;
export type InsertGovernmentScheme = z.infer<typeof insertGovernmentSchemeSchema>;

// Legacy user table for compatibility
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
