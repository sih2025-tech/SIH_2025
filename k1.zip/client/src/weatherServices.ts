// AccuWeather API Integration Service for Real-time Weather Conditions
import { LocationData } from './locationService';

export interface AccuWeatherResponse {
  locationKey: string;
  currentConditions: {
    temperature: {
      metric: number;
      imperial: number;
    };
    realFeelTemperature: {
      metric: number;
      imperial: number;
    };
    humidity: number;
    pressure: {
      metric: number;
      imperial: number;
    };
    visibility: {
      metric: number;
      imperial: number;
    };
    uvIndex: number;
    cloudCover: number;
    windSpeed: {
      metric: number;
      imperial: number;
    };
    windDirection: {
      degrees: number;
      localized: string;
    };
    precipitation: {
      metric: number;
      imperial: number;
    };
    weatherText: string;
    weatherIcon: number;
    isDayTime: boolean;
  };
  airQuality?: {
    index: number;
    category: string;
    color: string;
    categoryDescription: string;
    dominantPollutant: string;
  };
  forecast: Array<{
    date: string;
    temperature: {
      minimum: number;
      maximum: number;
    };
    precipitation: {
      probability: number;
      amount: number;
    };
    conditions: string;
    conditionsMarathi: string;
    windSpeed: number;
    humidity: number;
  }>;
  alerts: Array<{
    type: string;
    severity: 'minor' | 'moderate' | 'severe' | 'extreme';
    headline: string;
    headlineMarathi: string;
    description: string;
    descriptionMarathi: string;
    startTime: string;
    endTime: string;
    areas: string[];
  }>;
  agriculturalIndices: {
    soilMoisture: {
      value: number;
      category: 'very_dry' | 'dry' | 'adequate' | 'wet' | 'very_wet';
      recommendation: string;
      recommendationMarathi: string;
    };
    evapotranspiration: {
      value: number;
      category: 'low' | 'moderate' | 'high' | 'very_high';
      recommendation: string;
      recommendationMarathi: string;
    };
    pestPressure: {
      value: number;
      category: 'low' | 'moderate' | 'high' | 'very_high';
      recommendation: string;
      recommendationMarathi: string;
    };
    diseaseRisk: {
      value: number;
      category: 'low' | 'moderate' | 'high' | 'very_high';
      recommendation: string;
      recommendationMarathi: string;
    };
  };
}

export interface WeatherAlert {
  id: string;
  type: 'drought' | 'flood' | 'storm' | 'heat_wave' | 'frost' | 'fog' | 'cyclone';
  severity: 'minor' | 'moderate' | 'severe' | 'extreme';
  title: string;
  titleMarathi: string;
  description: string;
  descriptionMarathi: string;
  startTime: Date;
  endTime: Date;
  affectedAreas: string[];
  recommendations: string[];
  recommendationsMarathi: string[];
  isActive: boolean;
}

class WeatherService {
  private baseUrl = '/api/weather';

  async getCurrentWeather(location: LocationData): Promise<AccuWeatherResponse> {
    try {
      // First, get location key from AccuWeather
      const locationKey = await this.getLocationKey(location.latitude, location.longitude);
      
      // Get current conditions
      const currentConditions = await this.getCurrentConditions(locationKey);
      
      // Get air quality data
      const airQuality = await this.getAirQuality(locationKey);
      
      // Get forecast
      const forecast = await this.getForecast(locationKey);
      
      // Get weather alerts
      const alerts = await this.getWeatherAlerts(locationKey);
      
      // Calculate agricultural indices
      const agriculturalIndices = this.calculateAgriculturalIndices(currentConditions, forecast);

      return {
        locationKey,
        currentConditions,
        airQuality,
        forecast,
        alerts,
        agriculturalIndices
      };
    } catch (error) {
      console.error('AccuWeather API error:', error);
      // Fallback to mock data
      return this.getMockWeatherData(location);
    }
  }

  private async getLocationKey(latitude: number, longitude: number): Promise<string> {
    const url = `http://dataservice.accuweather.com/locations/v1/cities/geoposition/search`;
    const params = new URLSearchParams({
      apikey: this.accuWeatherApiKey,
      q: `${latitude},${longitude}`,
      language: 'en-us',
      details: 'true'
    });

    const response = await fetch(`${url}?${params}`);
    if (!response.ok) {
      throw new Error(`AccuWeather location lookup failed: ${response.statusText}`);
    }

    const data = await response.json();
    return data.Key;
  }

  private async getCurrentConditions(locationKey: string): Promise<AccuWeatherResponse['currentConditions']> {
    const url = `http://dataservice.accuweather.com/currentconditions/v1/${locationKey}`;
    const params = new URLSearchParams({
      apikey: this.accuWeatherApiKey,
      language: 'en-us',
      details: 'true'
    });

    const response = await fetch(`${url}?${params}`);
    if (!response.ok) {
      throw new Error(`AccuWeather current conditions failed: ${response.statusText}`);
    }

    const data = await response.json();
    const condition = data[0];

    return {
      temperature: {
        metric: condition.Temperature.Metric.Value,
        imperial: condition.Temperature.Imperial.Value
      },
      realFeelTemperature: {
        metric: condition.RealFeelTemperature.Metric.Value,
        imperial: condition.RealFeelTemperature.Imperial.Value
      },
      humidity: condition.RelativeHumidity,
      pressure: {
        metric: condition.Pressure.Metric.Value,
        imperial: condition.Pressure.Imperial.Value
      },
      visibility: {
        metric: condition.Visibility.Metric.Value,
        imperial: condition.Visibility.Imperial.Value
      },
      uvIndex: condition.UVIndex,
      cloudCover: condition.CloudCover,
      windSpeed: {
        metric: condition.Wind.Speed.Metric.Value,
        imperial: condition.Wind.Speed.Imperial.Value
      },
      windDirection: {
        degrees: condition.Wind.Direction.Degrees,
        localized: condition.Wind.Direction.Localized
      },
      precipitation: {
        metric: condition.PrecipitationSummary?.Past24Hours?.Metric?.Value || 0,
        imperial: condition.PrecipitationSummary?.Past24Hours?.Imperial?.Value || 0
      },
      weatherText: condition.WeatherText,
      weatherIcon: condition.WeatherIcon,
      isDayTime: condition.IsDayTime
    };
  }

  private async getAirQuality(locationKey: string): Promise<AccuWeatherResponse['airQuality']> {
    try {
      const url = `http://dataservice.accuweather.com/indices/v1/daily/1day/${locationKey}`;
      const params = new URLSearchParams({
        apikey: this.accuWeatherApiKey,
        details: 'true'
      });

      const response = await fetch(`${url}?${params}`);
      if (!response.ok) {
        return undefined; // Air quality may not be available for all locations
      }

      const data = await response.json();
      const airQualityIndex = data.find((index: any) => index.Name === 'Air Quality');

      if (airQualityIndex) {
        return {
          index: airQualityIndex.Value,
          category: airQualityIndex.Category,
          color: this.getAirQualityColor(airQualityIndex.Value),
          categoryDescription: airQualityIndex.CategoryValue,
          dominantPollutant: airQualityIndex.Text || 'Unknown'
        };
      }

      return undefined;
    } catch (error) {
      console.warn('Air quality data not available:', error);
      return undefined;
    }
  }

  private async getForecast(locationKey: string): Promise<AccuWeatherResponse['forecast']> {
    const url = `http://dataservice.accuweather.com/forecasts/v1/daily/5day/${locationKey}`;
    const params = new URLSearchParams({
      apikey: this.accuWeatherApiKey,
      language: 'en-us',
      details: 'true',
      metric: 'true'
    });

    const response = await fetch(`${url}?${params}`);
    if (!response.ok) {
      throw new Error(`AccuWeather forecast failed: ${response.statusText}`);
    }

    const data = await response.json();
    
    return data.DailyForecasts.map((day: any) => ({
      date: day.Date,
      temperature: {
        minimum: day.Temperature.Minimum.Value,
        maximum: day.Temperature.Maximum.Value
      },
      precipitation: {
        probability: day.Day.PrecipitationProbability,
        amount: day.Day.TotalLiquid?.Value || 0
      },
      conditions: day.Day.IconPhrase,
      conditionsMarathi: this.translateConditionsToMarathi(day.Day.IconPhrase),
      windSpeed: day.Day.Wind.Speed.Value,
      humidity: day.Day.RelativeHumidity?.Average || 0
    }));
  }

  private async getWeatherAlerts(locationKey: string): Promise<AccuWeatherResponse['alerts']> {
    try {
      const url = `http://dataservice.accuweather.com/alerts/v1/${locationKey}`;
      const params = new URLSearchParams({
        apikey: this.accuWeatherApiKey,
        language: 'en-us',
        details: 'true'
      });

      const response = await fetch(`${url}?${params}`);
      if (!response.ok) {
        return []; // No alerts
      }

      const data = await response.json();
      
      return data.map((alert: any) => ({
        type: this.categorizeAlertType(alert.Category),
        severity: this.mapSeverity(alert.Severity),
        headline: alert.Headline.Text,
        headlineMarathi: this.translateToMarathi(alert.Headline.Text),
        description: alert.Description.Text,
        descriptionMarathi: this.translateToMarathi(alert.Description.Text),
        startTime: alert.EffectiveDate,
        endTime: alert.ExpireDate,
        areas: alert.Areas?.map((area: any) => area.Text) || []
      }));
    } catch (error) {
      console.warn('Weather alerts not available:', error);
      return [];
    }
  }

  private calculateAgriculturalIndices(
    currentConditions: AccuWeatherResponse['currentConditions'],
    forecast: AccuWeatherResponse['forecast']
  ): AccuWeatherResponse['agriculturalIndices'] {
    // Calculate soil moisture based on recent precipitation and temperature
    const recentPrecipitation = currentConditions.precipitation.metric;
    const temperature = currentConditions.temperature.metric;
    const humidity = currentConditions.humidity;

    // Soil moisture calculation (simplified)
    let soilMoistureValue = 50; // Base value
    soilMoistureValue += recentPrecipitation * 10; // Increase with precipitation
    soilMoistureValue -= (temperature - 25) * 2; // Decrease with high temperature
    soilMoistureValue += (humidity - 50) * 0.5; // Adjust for humidity
    soilMoistureValue = Math.max(0, Math.min(100, soilMoistureValue));

    // Evapotranspiration calculation
    const etValue = this.calculateEvapotranspiration(temperature, humidity, currentConditions.windSpeed.metric);

    // Pest pressure calculation (higher in warm, humid conditions)
    const pestPressure = this.calculatePestPressure(temperature, humidity, forecast);

    // Disease risk calculation (higher in cool, humid conditions)
    const diseaseRisk = this.calculateDiseaseRisk(temperature, humidity, recentPrecipitation);

    return {
      soilMoisture: {
        value: soilMoistureValue,
        category: this.categorizeSoilMoisture(soilMoistureValue),
        recommendation: this.getSoilMoistureRecommendation(soilMoistureValue),
        recommendationMarathi: this.getSoilMoistureRecommendationMarathi(soilMoistureValue)
      },
      evapotranspiration: {
        value: etValue,
        category: this.categorizeEvapotranspiration(etValue),
        recommendation: this.getEvapotranspirationRecommendation(etValue),
        recommendationMarathi: this.getEvapotranspirationRecommendationMarathi(etValue)
      },
      pestPressure: {
        value: pestPressure,
        category: this.categorizePestPressure(pestPressure),
        recommendation: this.getPestPressureRecommendation(pestPressure),
        recommendationMarathi: this.getPestPressureRecommendationMarathi(pestPressure)
      },
      diseaseRisk: {
        value: diseaseRisk,
        category: this.categorizeDiseaseRisk(diseaseRisk),
        recommendation: this.getDiseaseRiskRecommendation(diseaseRisk),
        recommendationMarathi: this.getDiseaseRiskRecommendationMarathi(diseaseRisk)
      }
    };
  }

  // Helper methods for calculations and categorizations
  private calculateEvapotranspiration(temperature: number, humidity: number, windSpeed: number): number {
    // Simplified Penman-Monteith equation
    const netRadiation = temperature * 0.5; // Simplified
    const aerodynamicResistance = 208 / windSpeed;
    const et = (0.408 * netRadiation + 900 / (temperature + 273) * windSpeed * (0.01 * (100 - humidity))) / 
              (1 + 0.34 * windSpeed);
    return Math.max(0, et);
  }

  private calculatePestPressure(temperature: number, humidity: number, forecast: AccuWeatherResponse['forecast']): number {
    let pressure = 0;
    
    // Temperature factor (optimal range 25-35°C for most pests)
    if (temperature >= 25 && temperature <= 35) {
      pressure += 40;
    } else if (temperature >= 20 && temperature <= 40) {
      pressure += 20;
    }
    
    // Humidity factor (high humidity increases pest activity)
    if (humidity > 70) {
      pressure += 30;
    } else if (humidity > 50) {
      pressure += 15;
    }
    
    // Recent weather patterns
    const recentRain = forecast.slice(0, 3).some(day => day.precipitation.probability > 50);
    if (recentRain) {
      pressure += 20;
    }
    
    return Math.min(100, pressure);
  }

  private calculateDiseaseRisk(temperature: number, humidity: number, precipitation: number): number {
    let risk = 0;
    
    // Cool, humid conditions increase disease risk
    if (temperature >= 15 && temperature <= 25 && humidity > 80) {
      risk += 50;
    } else if (humidity > 70) {
      risk += 30;
    }
    
    // Recent precipitation increases fungal disease risk
    if (precipitation > 5) {
      risk += 30;
    } else if (precipitation > 1) {
      risk += 15;
    }
    
    return Math.min(100, risk);
  }

  // Categorization methods
  private categorizeSoilMoisture(value: number): 'very_dry' | 'dry' | 'adequate' | 'wet' | 'very_wet' {
    if (value < 20) return 'very_dry';
    if (value < 40) return 'dry';
    if (value < 70) return 'adequate';
    if (value < 85) return 'wet';
    return 'very_wet';
  }

  private categorizeEvapotranspiration(value: number): 'low' | 'moderate' | 'high' | 'very_high' {
    if (value < 2) return 'low';
    if (value < 4) return 'moderate';
    if (value < 6) return 'high';
    return 'very_high';
  }

  private categorizePestPressure(value: number): 'low' | 'moderate' | 'high' | 'very_high' {
    if (value < 25) return 'low';
    if (value < 50) return 'moderate';
    if (value < 75) return 'high';
    return 'very_high';
  }

  private categorizeDiseaseRisk(value: number): 'low' | 'moderate' | 'high' | 'very_high' {
    if (value < 25) return 'low';
    if (value < 50) return 'moderate';
    if (value < 75) return 'high';
    return 'very_high';
  }

  // Recommendation methods
  private getSoilMoistureRecommendation(value: number): string {
    const category = this.categorizeSoilMoisture(value);
    const recommendations = {
      very_dry: 'Immediate irrigation required. Deep watering recommended.',
      dry: 'Schedule irrigation within 24 hours. Monitor soil moisture.',
      adequate: 'Soil moisture is optimal. Continue regular monitoring.',
      wet: 'Reduce irrigation frequency. Ensure proper drainage.',
      very_wet: 'Stop irrigation. Check for waterlogging and improve drainage.'
    };
    return recommendations[category];
  }

  private getSoilMoistureRecommendationMarathi(value: number): string {
    const category = this.categorizeSoilMoisture(value);
    const recommendations = {
      very_dry: 'तात्काळ सिंचन आवश्यक. खोल पाणी देणे शिफारसीय.',
      dry: '24 तासांत सिंचन करा. मातीची ओलावा तपासत रहा.',
      adequate: 'मातीची ओलावा योग्य आहे. नियमित निरीक्षण चालू ठेवा.',
      wet: 'सिंचनाची वारंवारता कमी करा. योग्य निचरा सुनिश्चित करा.',
      very_wet: 'सिंचन थांबवा. पाणी साचण्याची तपासणी करा आणि निचरा सुधारा.'
    };
    return recommendations[category];
  }

  private getEvapotranspirationRecommendation(value: number): string {
    const category = this.categorizeEvapotranspiration(value);
    const recommendations = {
      low: 'Normal irrigation schedule sufficient.',
      moderate: 'Monitor soil moisture. Adjust irrigation as needed.',
      high: 'Increase irrigation frequency. Consider mulching.',
      very_high: 'Frequent irrigation required. Use mulch and shade if possible.'
    };
    return recommendations[category];
  }

  private getEvapotranspirationRecommendationMarathi(value: number): string {
    const category = this.categorizeEvapotranspiration(value);
    const recommendations = {
      low: 'सामान्य सिंचन वेळापत्रक पुरेसे आहे.',
      moderate: 'मातीची ओलावा तपासा. आवश्यकतेनुसार सिंचन समायोजित करा.',
      high: 'सिंचनाची वारंवारता वाढवा. गवत घालण्याचा विचार करा.',
      very_high: 'वारंवार सिंचन आवश्यक. गवत आणि शक्यतो सावली वापरा.'
    };
    return recommendations[category];
  }

  private getPestPressureRecommendation(value: number): string {
    const category = this.categorizePestPressure(value);
    const recommendations = {
      low: 'Continue regular monitoring. No immediate action needed.',
      moderate: 'Increase field monitoring. Prepare preventive measures.',
      high: 'Implement pest control measures. Monitor daily.',
      very_high: 'Immediate pest control action required. Consult agricultural expert.'
    };
    return recommendations[category];
  }

  private getPestPressureRecommendationMarathi(value: number): string {
    const category = this.categorizePestPressure(value);
    const recommendations = {
      low: 'नियमित निरीक्षण चालू ठेवा. तात्काळ कारवाईची गरज नाही.',
      moderate: 'शेतातील निरीक्षण वाढवा. प्रतिबंधात्मक उपाय तयार करा.',
      high: 'कीटक नियंत्रण उपाय अंमलात आणा. दररोज निरीक्षण करा.',
      very_high: 'तात्काळ कीटक नियंत्रण कारवाई आवश्यक. कृषी तज्ञांचा सल्ला घ्या.'
    };
    return recommendations[category];
  }

  private getDiseaseRiskRecommendation(value: number): string {
    const category = this.categorizeDiseaseRisk(value);
    const recommendations = {
      low: 'Continue regular field hygiene practices.',
      moderate: 'Monitor for disease symptoms. Ensure good air circulation.',
      high: 'Apply preventive fungicide spray. Remove affected plant parts.',
      very_high: 'Immediate disease control measures required. Isolate affected areas.'
    };
    return recommendations[category];
  }

  private getDiseaseRiskRecommendationMarathi(value: number): string {
    const category = this.categorizeDiseaseRisk(value);
    const recommendations = {
      low: 'नियमित शेत स्वच्छता पद्धती चालू ठेवा.',
      moderate: 'रोगाची लक्षणे तपासा. चांगली हवा फिरवण्याची व्यवस्था करा.',
      high: 'प्रतिबंधात्मक बुरशीनाशक फवारणी करा. बाधित भाग काढून टाका.',
      very_high: 'तात्काळ रोग नियंत्रण उपाय आवश्यक. बाधित भाग वेगळे करा.'
    };
    return recommendations[category];
  }

  // Utility methods
  private getAirQualityColor(index: number): string {
    if (index <= 50) return '#00e400'; // Good - Green
    if (index <= 100) return '#ffff00'; // Moderate - Yellow
    if (index <= 150) return '#ff7e00'; // Unhealthy for Sensitive - Orange
    if (index <= 200) return '#ff0000'; // Unhealthy - Red
    if (index <= 300) return '#8f3f97'; // Very Unhealthy - Purple
    return '#7e0023'; // Hazardous - Maroon
  }

  private categorizeAlertType(category: string): string {
    const lowerCategory = category.toLowerCase();
    if (lowerCategory.includes('storm') || lowerCategory.includes('thunder')) return 'storm';
    if (lowerCategory.includes('flood') || lowerCategory.includes('rain')) return 'flood';
    if (lowerCategory.includes('heat')) return 'heat_wave';
    if (lowerCategory.includes('frost') || lowerCategory.includes('freeze')) return 'frost';
    if (lowerCategory.includes('fog')) return 'fog';
    if (lowerCategory.includes('cyclone') || lowerCategory.includes('hurricane')) return 'cyclone';
    if (lowerCategory.includes('drought')) return 'drought';
    return category.toLowerCase();
  }

  private mapSeverity(severity: string): 'minor' | 'moderate' | 'severe' | 'extreme' {
    const lowerSeverity = severity.toLowerCase();
    if (lowerSeverity.includes('minor')) return 'minor';
    if (lowerSeverity.includes('moderate')) return 'moderate';
    if (lowerSeverity.includes('severe')) return 'severe';
    if (lowerSeverity.includes('extreme')) return 'extreme';
    return 'moderate'; // Default
  }

  private translateConditionsToMarathi(conditions: string): string {
    const translations: Record<string, string> = {
      'Sunny': 'सूर्यप्रकाश',
      'Partly Cloudy': 'अंशतः ढगाळ',
      'Cloudy': 'ढगाळ',
      'Overcast': 'पूर्ण ढगाळ',
      'Rain': 'पाऊस',
      'Heavy Rain': 'मुसळधार पाऊस',
      'Light Rain': 'हलका पाऊस',
      'Thunderstorms': 'गडगडाट',
      'Fog': 'धुके',
      'Mist': 'नीहार',
      'Clear': 'साफ',
      'Windy': 'वादळी'
    };
    return translations[conditions] || conditions;
  }

  private translateToMarathi(text: string): string {
    // In production, integrate with a proper translation API
    // For now, return a simplified translation or the original text
    return text; // Placeholder - integrate with Google Translate API or similar
  }

  // Mock data for development/fallback
  private getMockWeatherData(location: LocationData): AccuWeatherResponse {
    return {
      locationKey: 'mock-key',
      currentConditions: {
        temperature: { metric: 32, imperial: 89.6 },
        realFeelTemperature: { metric: 36, imperial: 96.8 },
        humidity: 65,
        pressure: { metric: 1012, imperial: 29.89 },
        visibility: { metric: 16, imperial: 10 },
        uvIndex: 7,
        cloudCover: 40,
        windSpeed: { metric: 12, imperial: 7.5 },
        windDirection: { degrees: 180, localized: 'South' },
        precipitation: { metric: 2.5, imperial: 0.1 },
        weatherText: 'Partly Cloudy',
        weatherIcon: 3,
        isDayTime: true
      },
      airQuality: {
        index: 45,
        category: 'Good',
        color: '#00e400',
        categoryDescription: 'Air quality is considered satisfactory',
        dominantPollutant: 'PM2.5'
      },
      forecast: [
        {
          date: '2024-01-15',
          temperature: { minimum: 18, maximum: 32 },
          precipitation: { probability: 30, amount: 2.5 },
          conditions: 'Partly Cloudy',
          conditionsMarathi: 'अंशतः ढगाळ',
          windSpeed: 12,
          humidity: 65
        },
        {
          date: '2024-01-16',
          temperature: { minimum: 20, maximum: 34 },
          precipitation: { probability: 10, amount: 0 },
          conditions: 'Sunny',
          conditionsMarathi: 'सूर्यप्रकाश',
          windSpeed: 8,
          humidity: 58
        }
      ],
      alerts: [
        {
          type: 'heat_wave',
          severity: 'moderate',
          headline: 'Heat Wave Warning',
          headlineMarathi: 'उष्णतेची लहरी चेतावणी',
          description: 'Temperature may reach 38°C in the coming days',
          descriptionMarathi: 'येत्या दिवसांत तापमान 38°C पर्यंत जाऊ शकते',
          startTime: '2024-01-16T06:00:00',
          endTime: '2024-01-18T18:00:00',
          areas: ['Jalna', 'Aurangabad']
        }
      ],
      agriculturalIndices: {
        soilMoisture: {
          value: 45,
          category: 'adequate',
          recommendation: 'Soil moisture is optimal. Continue regular monitoring.',
          recommendationMarathi: 'मातीची ओलावा योग्य आहे. नियमित निरीक्षण चालू ठेवा.'
        },
        evapotranspiration: {
          value: 4.2,
          category: 'moderate',
          recommendation: 'Monitor soil moisture. Adjust irrigation as needed.',
          recommendationMarathi: 'मातीची ओलावा तपासा. आवश्यकतेनुसार सिंचन समायोजित करा.'
        },
        pestPressure: {
          value: 60,
          category: 'moderate',
          recommendation: 'Increase field monitoring. Prepare preventive measures.',
          recommendationMarathi: 'शेतातील निरीक्षण वाढवा. प्रतिबंधात्मक उपाय तयार करा.'
        },
        diseaseRisk: {
          value: 35,
          category: 'moderate',
          recommendation: 'Monitor for disease symptoms. Ensure good air circulation.',
          recommendationMarathi: 'रोगाची लक्षणे तपासा. चांगली हवा फिरवण्याची व्यवस्था करा.'
        }
      }
    };
  }
}

// Singleton instance
export const weatherService = new WeatherService();