import { Switch, Route } from "wouter";
import { createOfflineQueryClient, useNetworkStatus } from "./lib/offlineQueryClient";
import { offlineService } from "./services/offlineService";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState, useEffect } from "react";
import NotFound from "@/pages/not-found";

// Components
import EnhancedChatInterface, { EnhancedMessage } from "@/components/EnhancedChatInterface";
import FarmerProfile, { FarmerProfileData } from "@/components/FarmerProfile";
import WeatherCard, { WeatherData } from "@/components/WeatherCard";
import MarketRatesCard, { MarketRate } from "@/components/MarketRatesCard";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, User, CloudSun, TrendingUp, Mic } from "lucide-react";

// Home Page Component
function Home() {
  // Chat state
  const [messages, setMessages] = useState<EnhancedMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);

  // TODO: remove mock functionality - Farmer profile state
  const [farmer, setFarmer] = useState<FarmerProfileData>({
    id: '1',
    name: 'राजेश पाटील / Rajesh Patil',
    phone: '+91 9876543210',
    location: 'जालना, महाराष्ट्र / Jalna, Maharashtra',
    farmSize: '5 एकर / 5 acres',
    preferredLanguage: 'mr',
    cropHistory: [
      {
        cropName: 'कापूस / Cotton',
        season: 'खरीप / Kharif',
        year: 2024,
        yield: '12 क्विंटल / 12 quintal',
        issues: ['पांढरी माशी / Whitefly', 'पावसामुळे नुकसान / Rain damage']
      },
      {
        cropName: 'सोयाबीन / Soybean',
        season: 'खरीप / Kharif', 
        year: 2023,
        yield: '8 क्विंटल / 8 quintal',
        issues: ['पर्णरोग / Leaf disease']
      }
    ],
    createdAt: new Date('2023-01-15')
  });
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  // TODO: remove mock functionality - Weather state
  const [weather, setWeather] = useState<WeatherData>({
    location: 'जालना, महाराष्ट्र / Jalna, Maharashtra',
    temperature: '32°C',
    humidity: '65%',
    rainfall: '2.5mm',
    windSpeed: '12 km/h',
    description: 'अंशतः ढगाळ / Partly Cloudy',
    alerts: ['उष्णतेची लहरी: तापमान 38°C पर्यंत जाऊ शकते / Heat Wave: Temperature may reach 38°C'],
    forecast: [
      { day: 'आज / Today', temp: '32°C', condition: 'अंशतः ढगाळ / Partly Cloudy' },
      { day: 'उद्या / Tomorrow', temp: '35°C', condition: 'साफ आकाश / Clear Sky' },
      { day: 'परवा / Day After', temp: '28°C', condition: 'पावसाची शक्यता / Chance of Rain' }
    ],
    lastUpdated: new Date()
  });

  // TODO: remove mock functionality - Market rates state
  const [marketRates, setMarketRates] = useState<MarketRate[]>([
    {
      cropName: 'कापूस / Cotton',
      market: 'जालना मार्केट / Jalna Market',
      pricePerUnit: '6,200',
      unit: 'क्विंटल / Quintal',
      date: new Date(),
      trend: 'up',
      change: '+₹150'
    },
    {
      cropName: 'सोयाबीन / Soybean',
      market: 'औरंगाबाद मार्केट / Aurangabad Market',
      pricePerUnit: '4,800', 
      unit: 'क्विंटल / Quintal',
      date: new Date(Date.now() - 86400000),
      trend: 'down',
      change: '-₹200'
    }
  ]);

  // Wake word detection simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setIsListening(Math.random() > 0.8); // Randomly show listening state
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Chat handlers
  const handleSendMessage = (data: {
    text: string;
    language?: string;
    intent?: any;
    location?: GeolocationPosition;
    image?: File;
  }) => {
    const newMessage: EnhancedMessage = {
      id: Date.now().toString(),
      text: data.text,
      isUser: true,
      timestamp: new Date(),
      detectedLanguage: data.language as any,
      intent: data.intent?.intent,
      confidence: data.intent?.confidence,
      entities: data.intent?.entities,
      location: data.location ? {
        latitude: data.location.coords.latitude,
        longitude: data.location.coords.longitude,
        accuracy: data.location.coords.accuracy
      } : undefined
    };
    setMessages(prev => [...prev, newMessage]);
    setIsLoading(true);
    
    // TODO: replace with real AI service integration
    setTimeout(() => {
      const responses = {
        weather: 'आजचे हवामान: तापमान 32°C, आर्द्रता 65%. शेतीसाठी योग्य वातावरण आहे. / Today\'s weather: Temperature 32°C, humidity 65%. Good conditions for farming.',
        disease: 'पानांवर पिवळे डाग दिसले तर Early Blight असू शकतो. कॉपर सल्फेटची फवारणी करा. / If yellow spots appear on leaves, it could be Early Blight. Spray copper sulfate.',
        market: 'कापसाचे भाव आज ₹6,200 प्रति क्विंटल आहेत. मागील आठवड्यापेक्षा ₹150 वाढले आहेत. / Cotton prices today are ₹6,200 per quintal. Up by ₹150 from last week.',
        general: 'मी तुमची कृषी सहायक आहे. हवामान, रोग, बाजार भाव याबद्दल विचारू शकता. / I am your agricultural assistant. You can ask about weather, diseases, market rates.'
      };
      
      let response = responses.general;
      const lowerText = data.text.toLowerCase();
      if (lowerText.includes('weather') || lowerText.includes('हवामान')) response = responses.weather;
      if (lowerText.includes('disease') || lowerText.includes('रोग') || lowerText.includes('डाग')) response = responses.disease;
      if (lowerText.includes('market') || lowerText.includes('भाव') || lowerText.includes('price')) response = responses.market;
      
      const aiMessage: EnhancedMessage = {
        id: Date.now().toString() + '_ai',
        text: response,
        isUser: false,
        timestamp: new Date(),
        detectedLanguage: 'mr'
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsLoading(false);
    }, 2000);
  };

  // Location state
  const [currentLocation, setCurrentLocation] = useState<GeolocationPosition | undefined>();

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => setCurrentLocation(position),
        (error) => console.log('Location error:', error)
      );
    }
  }, []);

  // Other handlers  
  const handleUpdateProfile = (updates: Partial<FarmerProfileData>) => {
    setFarmer(prev => ({ ...prev, ...updates }));
    console.log('Profile updated:', updates);
  };

  const handleRefreshWeather = () => {
    console.log('Refreshing weather...');
    // TODO: remove mock functionality - simulate weather API call
    const newTemp = Math.floor(Math.random() * 10) + 25;
    setWeather(prev => ({ ...prev, temperature: `${newTemp}°C`, lastUpdated: new Date() }));
  };

  const handleRefreshMarketRates = () => {
    console.log('Refreshing market rates...');
    // TODO: remove mock functionality - simulate market API call
    setMarketRates(prev => prev.map(rate => ({
      ...rate,
      pricePerUnit: (parseInt(rate.pricePerUnit.replace(',', '')) + Math.floor(Math.random() * 200) - 100).toLocaleString(),
      date: new Date()
    })));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container max-w-screen-xl mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">कृ</span>
            </div>
            <div>
              <h1 className="text-xl font-semibold">कृषी सहायक / Krishi Assistant</h1>
              <p className="text-xs text-muted-foreground">Your Agricultural Companion</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {isListening && (
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                <Mic className="w-3 h-3 mr-1" />
                Listening...
              </Badge>
            )}
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-screen-xl mx-auto p-4">
        <Tabs defaultValue="chat" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="chat" className="flex items-center gap-2" data-testid="tab-chat">
              <MessageSquare className="w-4 h-4" />
              <span className="hidden sm:inline">Chat</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center gap-2" data-testid="tab-profile">
              <User className="w-4 h-4" />
              <span className="hidden sm:inline">Profile</span>
            </TabsTrigger>
            <TabsTrigger value="weather" className="flex items-center gap-2" data-testid="tab-weather">
              <CloudSun className="w-4 h-4" />
              <span className="hidden sm:inline">Weather</span>
            </TabsTrigger>
            <TabsTrigger value="market" className="flex items-center gap-2" data-testid="tab-market">
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Market</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="space-y-4">
            <Card className="h-[70vh] overflow-hidden">
              <EnhancedChatInterface
                messages={messages}
                onSendMessage={handleSendMessage}
                isLoading={isLoading}
                isListening={isListening}
                currentLocation={currentLocation}
              />
            </Card>
          </TabsContent>

          <TabsContent value="profile" className="space-y-4">
            <FarmerProfile
              farmer={farmer}
              onUpdateProfile={handleUpdateProfile}
              isEditing={isEditingProfile}
              onToggleEdit={() => setIsEditingProfile(prev => !prev)}
            />
          </TabsContent>

          <TabsContent value="weather" className="space-y-4">
            <div className="grid grid-cols-1 max-w-md mx-auto">
              <WeatherCard
                weather={weather}
                onRefresh={handleRefreshWeather}
              />
            </div>
          </TabsContent>

          <TabsContent value="market" className="space-y-4">
            <div className="grid grid-cols-1 max-w-md mx-auto">
              <MarketRatesCard
                rates={marketRates}
                onRefresh={handleRefreshMarketRates}
              />
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/30 py-6 mt-12">
        <div className="container max-w-screen-xl mx-auto px-4">
          <div className="text-center text-sm text-muted-foreground">
            <p>शेतकऱ्यांसाठी आधुनिक तंत्रज्ञानाचा वापर / Modern technology for farmers</p>
            <p className="mt-1">Made with ❤️ for Indian Agriculture</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [offlineQueryClient] = useState(() => createOfflineQueryClient());
  const [isOfflineInitialized, setIsOfflineInitialized] = useState(false);

  useEffect(() => {
    const initOffline = async () => {
      try {
        await offlineService.init();
        offlineService.startSyncListeners();
        setIsOfflineInitialized(true);
        console.log('Offline service initialized successfully');
      } catch (error) {
        console.error('Failed to initialize offline service:', error);
        setIsOfflineInitialized(true); // Continue without offline support
      }
    };

    initOffline();

    return () => {
      offlineService.close();
    };
  }, []);

  if (!isOfflineInitialized) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
            <span className="text-primary-foreground font-bold text-sm">कृ</span>
          </div>
          <h1 className="text-xl font-semibold mb-2">कृषी सहायक / Krishi Assistant</h1>
          <p className="text-muted-foreground">Initializing offline capabilities...</p>
        </div>
      </div>
    );
  }

  return (
    <QueryClientProvider client={offlineQueryClient}>
      <TooltipProvider>
        <Toaster />
        <OfflineIndicator />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

// Offline status indicator
function OfflineIndicator() {
  const { isOnline } = useNetworkStatus();

  if (isOnline) return null;

  return (
    <div className="fixed top-0 left-0 right-0 bg-amber-500 text-white px-4 py-2 text-center text-sm z-50">
      <span className="font-medium">ऑफलाइन मोड / Offline Mode</span> - Your data will sync when connection is restored
    </div>
  );
}

export default App;