import { openDB, DBSchema, IDBPDatabase } from 'idb';

interface OfflineDBSchema extends DBSchema {
  queries: {
    key: string;
    value: {
      id: string;
      farmerId: string;
      originalQuery: string;
      intent: string;
      response: string;
      latitude: string | null;
      longitude: string | null;
      detectedLanguage: string | null;
      transcribedText: string | null;
      entities: any;
      confidence: string | null;
      satisfied: boolean | null;
      sessionId: string | null;
      createdAt: Date;
      synced: number; // 0 = not synced, 1 = synced
    };
    indexes: {
      'by-farmerId': string;
      'by-createdAt': Date;
      'by-synced': number;
    };
  };
  pendingMutations: {
    key: string;
    value: {
      id: string;
      method: 'POST' | 'PUT' | 'DELETE';
      url: string;
      body: any;
      timestamp: Date;
      retryCount: number;
    };
    indexes: {
      'by-timestamp': Date;
    };
  };
  mlPredictions: {
    key: string;
    value: {
      id: string;
      farmerId: string;
      modelType: string;
      inputData: any;
      prediction: any;
      confidence: string | null;
      status: string | null;
      modelVersion: string | null;
      processingTime: number | null;
      errorMessage: string | null;
      createdAt: Date;
      synced: number; // 0 = not synced, 1 = synced
    };
    indexes: {
      'by-farmerId': string;
      'by-createdAt': Date;
      'by-synced': number;
    };
  };
  weatherData: {
    key: string;
    value: {
      id: string;
      location: string;
      date: Date;
      latitude: string | null;
      longitude: string | null;
      temperature: string | null;
      humidity: string | null;
      rainfall: string | null;
      windSpeed: string | null;
      forecast: any;
      alerts: any;
      source: string | null;
      airQuality: string | null;
      visibility: string | null;
      pressure: string | null;
      uvIndex: string | null;
      cloudCover: string | null;
      fogConditions: string | null;
      synced: number; // 0 = not synced, 1 = synced
    };
    indexes: {
      'by-location': string;
      'by-date': Date;
      'by-synced': number;
    };
  };
}

export class OfflineService {
  private db: IDBPDatabase<OfflineDBSchema> | null = null;
  private syncInProgress = false;

  async init(): Promise<void> {
    try {
      this.db = await openDB<OfflineDBSchema>('KrishiAI', 1, {
        upgrade(db) {
          // Queries store
          if (!db.objectStoreNames.contains('queries')) {
            const queryStore = db.createObjectStore('queries', {
              keyPath: 'id'
            });
            queryStore.createIndex('by-farmerId', 'farmerId');
            queryStore.createIndex('by-synced', 'synced');
            queryStore.createIndex('by-createdAt', 'createdAt');
          }

          // Pending mutations store
          if (!db.objectStoreNames.contains('pendingMutations')) {
            const mutationStore = db.createObjectStore('pendingMutations', {
              keyPath: 'id'
            });
            mutationStore.createIndex('by-timestamp', 'timestamp');
          }

          // ML predictions store
          if (!db.objectStoreNames.contains('mlPredictions')) {
            const mlStore = db.createObjectStore('mlPredictions', {
              keyPath: 'id'
            });
            mlStore.createIndex('by-farmerId', 'farmerId');
            mlStore.createIndex('by-synced', 'synced');
            mlStore.createIndex('by-createdAt', 'createdAt');
          }

          // Weather data store
          if (!db.objectStoreNames.contains('weatherData')) {
            const weatherStore = db.createObjectStore('weatherData', {
              keyPath: 'id'
            });
            weatherStore.createIndex('by-location', 'location');
            weatherStore.createIndex('by-synced', 'synced');
            weatherStore.createIndex('by-date', 'date');
          }
        },
      });
    } catch (error) {
      console.error('Failed to initialize IndexedDB:', error);
    }
  }

  // Query operations
  async saveQuery(query: any): Promise<void> {
    if (!this.db) return;
    
    try {
      await this.db.put('queries', {
        ...query,
        synced: navigator.onLine ? 1 : 0
      });
    } catch (error) {
      console.error('Failed to save query offline:', error);
    }
  }

  async getQueries(farmerId: string): Promise<any[]> {
    if (!this.db) return [];
    
    try {
      const tx = this.db.transaction('queries', 'readonly');
      const index = tx.store.index('by-farmerId');
      return await index.getAll(farmerId);
    } catch (error) {
      console.error('Failed to get queries offline:', error);
      return [];
    }
  }

  async getUnsyncedQueries(): Promise<any[]> {
    if (!this.db) return [];
    
    try {
      const tx = this.db.transaction('queries', 'readonly');
      const index = tx.store.index('by-synced');
      return await index.getAll(0);
    } catch (error) {
      console.error('Failed to get unsynced queries:', error);
      return [];
    }
  }

  // ML Prediction operations
  async saveMlPrediction(prediction: any): Promise<void> {
    if (!this.db) return;
    
    try {
      await this.db.put('mlPredictions', {
        ...prediction,
        synced: navigator.onLine ? 1 : 0
      });
    } catch (error) {
      console.error('Failed to save ML prediction offline:', error);
    }
  }

  async getMlPredictions(farmerId: string): Promise<any[]> {
    if (!this.db) return [];
    
    try {
      const tx = this.db.transaction('mlPredictions', 'readonly');
      const index = tx.store.index('by-farmerId');
      return await index.getAll(farmerId);
    } catch (error) {
      console.error('Failed to get ML predictions offline:', error);
      return [];
    }
  }

  async getUnsyncedMlPredictions(): Promise<any[]> {
    if (!this.db) return [];
    
    try {
      const tx = this.db.transaction('mlPredictions', 'readonly');
      const index = tx.store.index('by-synced');
      return await index.getAll(0);
    } catch (error) {
      console.error('Failed to get unsynced ML predictions:', error);
      return [];
    }
  }

  // Weather data operations
  async saveWeatherData(weatherData: any): Promise<void> {
    if (!this.db) return;
    
    try {
      await this.db.put('weatherData', {
        ...weatherData,
        synced: navigator.onLine ? 1 : 0
      });
    } catch (error) {
      console.error('Failed to save weather data offline:', error);
    }
  }

  async getWeatherData(location: string): Promise<any[]> {
    if (!this.db) return [];
    
    try {
      const tx = this.db.transaction('weatherData', 'readonly');
      const index = tx.store.index('by-location');
      return await index.getAll(location);
    } catch (error) {
      console.error('Failed to get weather data offline:', error);
      return [];
    }
  }

  async getUnsyncedWeatherData(): Promise<any[]> {
    if (!this.db) return [];
    
    try {
      const tx = this.db.transaction('weatherData', 'readonly');
      const index = tx.store.index('by-synced');
      return await index.getAll(0);
    } catch (error) {
      console.error('Failed to get unsynced weather data:', error);
      return [];
    }
  }

  // Pending mutations
  async addPendingMutation(mutation: {
    method: 'POST' | 'PUT' | 'DELETE';
    url: string;
    body: any;
  }): Promise<void> {
    if (!this.db) return;
    
    try {
      const id = `mutation_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await this.db.put('pendingMutations', {
        id,
        ...mutation,
        timestamp: new Date(),
        retryCount: 0
      });
    } catch (error) {
      console.error('Failed to add pending mutation:', error);
    }
  }

  async getPendingMutations(): Promise<any[]> {
    if (!this.db) return [];
    
    try {
      const tx = this.db.transaction('pendingMutations', 'readonly');
      const index = tx.store.index('by-timestamp');
      return await index.getAll();
    } catch (error) {
      console.error('Failed to get pending mutations:', error);
      return [];
    }
  }

  async removePendingMutation(id: string): Promise<void> {
    if (!this.db) return;
    
    try {
      await this.db.delete('pendingMutations', id);
    } catch (error) {
      console.error('Failed to remove pending mutation:', error);
    }
  }

  async markAsSynced(store: 'queries' | 'mlPredictions' | 'weatherData', id: string): Promise<void> {
    if (!this.db) return;
    
    try {
      const tx = this.db.transaction(store, 'readwrite');
      const item = await tx.store.get(id);
      if (item) {
        await tx.store.put({ ...item, synced: 1 });
      }
    } catch (error) {
      console.error(`Failed to mark ${store} item as synced:`, error);
    }
  }

  // Network connectivity and sync
  async isOnline(): Promise<boolean> {
    return navigator.onLine;
  }

  async sync(): Promise<void> {
    if (this.syncInProgress || !navigator.onLine) {
      return;
    }

    this.syncInProgress = true;

    try {
      await this.syncPendingMutations();
      await this.syncUnsyncedData();
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      this.syncInProgress = false;
    }
  }

  private async syncPendingMutations(): Promise<void> {
    const mutations = await this.getPendingMutations();
    
    for (const mutation of mutations) {
      try {
        const response = await fetch(mutation.url, {
          method: mutation.method,
          headers: {
            'Content-Type': 'application/json',
          },
          body: mutation.body ? JSON.stringify(mutation.body) : undefined,
        });

        if (response.ok) {
          await this.removePendingMutation(mutation.id);
        } else {
          // Increment retry count and potentially remove after max retries
          const maxRetries = 3;
          if (mutation.retryCount >= maxRetries) {
            await this.removePendingMutation(mutation.id);
          }
        }
      } catch (error) {
        console.error('Failed to sync mutation:', error);
      }
    }
  }

  private async syncUnsyncedData(): Promise<void> {
    // Sync queries
    const unsyncedQueries = await this.getUnsyncedQueries();
    for (const query of unsyncedQueries) {
      try {
        const response = await fetch('/api/chat/message', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(query),
        });

        if (response.ok) {
          await this.markAsSynced('queries', query.id);
        }
      } catch (error) {
        console.error('Failed to sync query:', error);
      }
    }

    // Sync ML predictions
    const unsyncedPredictions = await this.getUnsyncedMlPredictions();
    for (const prediction of unsyncedPredictions) {
      try {
        const endpoint = this.getMLEndpoint(prediction.modelType);
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(prediction),
        });

        if (response.ok) {
          await this.markAsSynced('mlPredictions', prediction.id);
        }
      } catch (error) {
        console.error('Failed to sync ML prediction:', error);
      }
    }

    // Sync weather data
    const unsyncedWeatherData = await this.getUnsyncedWeatherData();
    for (const weatherData of unsyncedWeatherData) {
      try {
        const response = await fetch('/api/weather/current', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(weatherData),
        });

        if (response.ok) {
          await this.markAsSynced('weatherData', weatherData.id);
        }
      } catch (error) {
        console.error('Failed to sync weather data:', error);
      }
    }
  }

  private getMLEndpoint(modelType: string): string {
    switch (modelType) {
      case 'disease_detection':
        return '/api/ml/disease-detection';
      case 'hyperlocal_weather':
        return '/api/ml/weather-prediction';
      case 'market_prediction':
        return '/api/ml/market-prediction';
      case 'crop_health':
        return '/api/ml/crop-health';
      default:
        return '/api/ml/prediction';
    }
  }

  // Initialize sync listeners
  startSyncListeners(): void {
    // Listen for online/offline events
    window.addEventListener('online', () => {
      console.log('Connection restored, starting sync...');
      this.sync();
    });

    window.addEventListener('offline', () => {
      console.log('Connection lost, switching to offline mode...');
    });

    // Periodic sync when online (every 5 minutes)
    setInterval(() => {
      if (navigator.onLine && !this.syncInProgress) {
        this.sync();
      }
    }, 5 * 60 * 1000);
  }

  // Cleanup
  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// Singleton instance
export const offlineService = new OfflineService();