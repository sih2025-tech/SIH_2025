// AI Service for ML Model Integration and Intent Processing
import { apiRequest } from '@/lib/queryClient';

export interface MLModelRequest {
  modelType: 'hyperlocal_weather' | 'market_rates' | 'disease_detection' | 'crop_health';
  inputData: any;
  farmerId?: string;
  location?: {
    latitude: number;
    longitude: number;
  };
}

export interface MLModelResponse {
  prediction: any;
  confidence: number;
  modelVersion: string;
  processingTime: number;
  recommendedActions?: string[];
}

export interface DiseaseDetectionRequest {
  image: File;
  cropName?: string;
  farmerId?: string;
  location?: {
    latitude: number;
    longitude: number;
  };
}

export interface DiseaseDetectionResponse {
  detectedDiseases: Array<{
    name: string;
    nameMarathi: string;
    confidence: number;
    severity: 'low' | 'medium' | 'high' | 'critical';
    description: string;
    descriptionMarathi: string;
  }>;
  recommendedTreatment: Array<{
    treatment: string;
    treatmentMarathi: string;
    urgency: 'immediate' | 'within_week' | 'monitor';
    cost?: string;
    availability?: string;
  }>;
  overallHealthScore: number;
  confidence: number;
}

export interface WeatherPredictionRequest {
  latitude: number;
  longitude: number;
  cropType?: string;
  predictionDays?: number;
  farmerId?: string;
}

export interface WeatherPredictionResponse {
  hyperLocalForecast: Array<{
    date: string;
    temperature: {
      min: number;
      max: number;
      avg: number;
    };
    rainfall: {
      probability: number;
      amount: number;
    };
    humidity: number;
    windSpeed: number;
    conditions: string;
    conditionsMarathi: string;
  }>;
  agriculturalAdvisory: {
    irrigation: string;
    irrigationMarathi: string;
    planting: string;
    plantingMarathi: string;
    harvesting: string;
    harvestingMarathi: string;
    pestControl: string;
    pestControlMarathi: string;
  };
  alerts: Array<{
    type: 'drought' | 'flood' | 'storm' | 'heat_wave' | 'frost';
    severity: 'low' | 'medium' | 'high' | 'critical';
    message: string;
    messageMarathi: string;
    startDate: string;
    endDate: string;
  }>;
  confidence: number;
}

export interface MarketPredictionRequest {
  cropName: string;
  location: {
    latitude: number;
    longitude: number;
  };
  quantity?: number;
  farmerId?: string;
}

export interface MarketPredictionResponse {
  currentPrices: Array<{
    market: string;
    price: number;
    unit: string;
    date: string;
    trend: 'up' | 'down' | 'stable';
  }>;
  predictions: Array<{
    period: '7d' | '30d' | '3m';
    predictedPrice: number;
    confidence: number;
    factors: string[];
  }>;
  recommendations: {
    bestTimeToSell: string;
    bestMarkets: string[];
    priceOptimizationTips: string[];
    priceOptimizationTipsMarathi: string[];
  };
  marketTrends: {
    demandForecast: 'increasing' | 'decreasing' | 'stable';
    supplyForecast: 'increasing' | 'decreasing' | 'stable';
    seasonalFactors: string[];
  };
}

export interface CropHealthRequest {
  cropType: string;
  farmerId?: string;
  location?: {
    latitude: number;
    longitude: number;
  };
  currentStage: 'sowing' | 'growing' | 'flowering' | 'fruiting' | 'harvesting';
  issues?: string[];
}

export interface CropHealthResponse {
  healthScore: number;
  recommendations: Array<{
    category: 'fertilizer' | 'irrigation' | 'pest_control' | 'disease_prevention' | 'general';
    recommendation: string;
    recommendationMarathi: string;
    priority: 'high' | 'medium' | 'low';
    timeline: string;
    estimatedCost?: string;
  }>;
  nutritionAnalysis: {
    nitrogen: 'sufficient' | 'deficient' | 'excess';
    phosphorus: 'sufficient' | 'deficient' | 'excess';
    potassium: 'sufficient' | 'deficient' | 'excess';
    micronutrients: Record<string, 'sufficient' | 'deficient' | 'excess'>;
  };
  expectedYield: {
    predicted: number;
    unit: string;
    confidence: number;
    factors: string[];
  };
}

class AIService {
  private baseUrl = '/api/ai';

  async predictDiseaseFromImage(request: DiseaseDetectionRequest): Promise<DiseaseDetectionResponse> {
    const formData = new FormData();
    formData.append('image', request.image);
    
    if (request.cropName) formData.append('cropName', request.cropName);
    if (request.farmerId) formData.append('farmerId', request.farmerId);
    if (request.location) {
      formData.append('latitude', request.location.latitude.toString());
      formData.append('longitude', request.location.longitude.toString());
    }

    try {
      const response = await fetch(`${this.baseUrl}/disease-detection`, {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error(`Disease detection failed: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Disease detection error:', error);
      // Fallback to mock response for development
      return this.getMockDiseaseDetection();
    }
  }

  async getHyperlocalWeather(request: WeatherPredictionRequest): Promise<WeatherPredictionResponse> {
    try {
      const response = await apiRequest('POST', `${this.baseUrl}/hyperlocal-weather`, request);
      return await response.json();
    } catch (error) {
      console.error('Hyperlocal weather prediction error:', error);
      return this.getMockWeatherPrediction();
    }
  }

  async getMarketPrediction(request: MarketPredictionRequest): Promise<MarketPredictionResponse> {
    try {
      const response = await apiRequest('POST', `${this.baseUrl}/market-prediction`, request);
      return await response.json();
    } catch (error) {
      console.error('Market prediction error:', error);
      return this.getMockMarketPrediction();
    }
  }

  async getCropHealthAnalysis(request: CropHealthRequest): Promise<CropHealthResponse> {
    try {
      const response = await apiRequest('POST', `${this.baseUrl}/crop-health`, request);
      return await response.json();
    } catch (error) {
      console.error('Crop health analysis error:', error);
      return this.getMockCropHealth();
    }
  }

  async getGovernmentSchemes(params: {
    cropType?: string;
    farmSize?: string;
    location?: string;
    schemeType?: string;
  }) {
    try {
      const searchParams = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        if (value) searchParams.append(key, value);
      });

      const response = await apiRequest('GET', `${this.baseUrl}/government-schemes?${searchParams}`);
      return await response.json();
    } catch (error) {
      console.error('Government schemes error:', error);
      return this.getMockGovernmentSchemes();
    }
  }

  // Mock responses for development/fallback
  private getMockDiseaseDetection(): DiseaseDetectionResponse {
    return {
      detectedDiseases: [
        {
          name: 'Early Blight',
          nameMarathi: 'पूर्व अंगारा रोग',
          confidence: 0.87,
          severity: 'medium',
          description: 'Fungal disease affecting leaves with brown spots and yellowing',
          descriptionMarathi: 'पानांवर तपकिरी डाग आणि पिवळेपणा असलेला बुरशीजन्य रोग'
        },
        {
          name: 'Leaf Spot',
          nameMarathi: 'पर्ण डाग',
          confidence: 0.65,
          severity: 'low',
          description: 'Minor leaf spotting, monitor for spread',
          descriptionMarathi: 'किरकोळ पर्ण डाग, पसरण्याचे निरीक्षण करा'
        }
      ],
      recommendedTreatment: [
        {
          treatment: 'Apply copper sulfate fungicide spray',
          treatmentMarathi: 'कॉपर सल्फेट बुरशीनाशक फवारणी करा',
          urgency: 'within_week',
          cost: '₹150-200 per acre',
          availability: 'Available at local agricultural stores'
        },
        {
          treatment: 'Improve field drainage and reduce humidity',
          treatmentMarathi: 'शेताची पाणी निचरा सुधारा आणि आर्द्रता कमी करा',
          urgency: 'immediate',
          cost: 'Minimal',
          availability: 'Farmer can implement'
        }
      ],
      overallHealthScore: 0.72,
      confidence: 0.84
    };
  }

  private getMockWeatherPrediction(): WeatherPredictionResponse {
    return {
      hyperLocalForecast: [
        {
          date: '2024-01-15',
          temperature: { min: 18, max: 32, avg: 25 },
          rainfall: { probability: 0.3, amount: 2.5 },
          humidity: 65,
          windSpeed: 12,
          conditions: 'Partly Cloudy',
          conditionsMarathi: 'अंशतः ढगाळ'
        },
        {
          date: '2024-01-16',
          temperature: { min: 20, max: 34, avg: 27 },
          rainfall: { probability: 0.1, amount: 0 },
          humidity: 58,
          windSpeed: 8,
          conditions: 'Clear Sky',
          conditionsMarathi: 'साफ आकाश'
        }
      ],
      agriculturalAdvisory: {
        irrigation: 'Light irrigation recommended in evening',
        irrigationMarathi: 'संध्याकाळी हलकी सिंचन करा',
        planting: 'Good conditions for sowing winter crops',
        plantingMarathi: 'हिवाळी पिकांच्या पेरणीसाठी योग्य परिस्थिती',
        harvesting: 'Favorable for harvesting mature crops',
        harvestingMarathi: 'परिपक्व पिकांच्या कापणीसाठी अनुकूल',
        pestControl: 'Monitor for pest activity in warm weather',
        pestControlMarathi: 'उष्ण हवामानात कीटकांच्या हालचालींचे निरीक्षण करा'
      },
      alerts: [
        {
          type: 'heat_wave',
          severity: 'medium',
          message: 'Temperature may reach 38°C. Ensure adequate irrigation.',
          messageMarathi: 'तापमान 38°C पर्यंत जाऊ शकते. पुरेशी सिंचन सुनिश्चित करा.',
          startDate: '2024-01-16',
          endDate: '2024-01-18'
        }
      ],
      confidence: 0.89
    };
  }

  private getMockMarketPrediction(): MarketPredictionResponse {
    return {
      currentPrices: [
        {
          market: 'Jalna APMC',
          price: 6200,
          unit: 'Quintal',
          date: '2024-01-15',
          trend: 'up'
        },
        {
          market: 'Aurangabad APMC',
          price: 6150,
          unit: 'Quintal',
          date: '2024-01-15',
          trend: 'stable'
        }
      ],
      predictions: [
        {
          period: '7d',
          predictedPrice: 6350,
          confidence: 0.78,
          factors: ['Increased demand', 'Weather conditions', 'Export demand']
        },
        {
          period: '30d',
          predictedPrice: 6500,
          confidence: 0.65,
          factors: ['Seasonal trends', 'Government policies', 'International prices']
        }
      ],
      recommendations: {
        bestTimeToSell: 'Next week (Jan 22-28)',
        bestMarkets: ['Jalna APMC', 'Mumbai APMC', 'Nagpur APMC'],
        priceOptimizationTips: [
          'Grade your produce properly',
          'Consider direct marketing to retailers',
          'Monitor daily price trends'
        ],
        priceOptimizationTipsMarathi: [
          'तुमच्या उत्पादनाची योग्य गुणवत्ता करा',
          'किरकोळ विक्रेत्यांना थेट विक्री करण्याचा विचार करा',
          'दैनंदिन किंमत ट्रेंडचे निरीक्षण करा'
        ]
      },
      marketTrends: {
        demandForecast: 'increasing',
        supplyForecast: 'stable',
        seasonalFactors: ['Peak harvest season ending', 'Festival demand increasing']
      }
    };
  }

  private getMockCropHealth(): CropHealthResponse {
    return {
      healthScore: 0.78,
      recommendations: [
        {
          category: 'fertilizer',
          recommendation: 'Apply NPK fertilizer (19:19:19) at 50kg per acre',
          recommendationMarathi: 'एनपीके खत (19:19:19) 50 किलो प्रति एकर वापरा',
          priority: 'high',
          timeline: 'Within 3 days',
          estimatedCost: '₹800-1000'
        },
        {
          category: 'irrigation',
          recommendation: 'Increase irrigation frequency to twice weekly',
          recommendationMarathi: 'सिंचनाची वारंवारता आठवड्यातून दोनदा वाढवा',
          priority: 'medium',
          timeline: 'Immediate',
          estimatedCost: 'Variable'
        }
      ],
      nutritionAnalysis: {
        nitrogen: 'deficient',
        phosphorus: 'sufficient',
        potassium: 'deficient',
        micronutrients: {
          zinc: 'deficient',
          iron: 'sufficient',
          manganese: 'sufficient'
        }
      },
      expectedYield: {
        predicted: 12.5,
        unit: 'Quintal per acre',
        confidence: 0.82,
        factors: ['Current health status', 'Weather predictions', 'Nutrition levels']
      }
    };
  }

  private getMockGovernmentSchemes() {
    return [
      {
        id: '1',
        title: 'PM-KISAN Scheme',
        titleMarathi: 'पीएम-किसान योजना',
        description: 'Income support of ₹6000 per year to small and marginal farmers',
        descriptionMarathi: 'लहान आणि सीमांत शेतकऱ्यांना वर्षाला ₹6000 उत्पन्न आधार',
        benefits: ['₹2000 every 4 months', 'Direct bank transfer', 'No intermediaries'],
        eligibility: {
          landSize: 'Up to 2 hectares',
          farmerType: 'Small and marginal farmers',
          documents: ['Land records', 'Bank account', 'Aadhaar card']
        },
        applicationProcess: 'Online through PM-KISAN portal or CSC centers',
        applicationProcessMarathi: 'पीएम-किसान पोर्टल किंवा सीएससी केंद्रांद्वारे ऑनलाइन',
        isActive: true,
        officialUrl: 'https://pmkisan.gov.in'
      },
      {
        id: '2',
        title: 'Pradhan Mantri Fasal Bima Yojana',
        titleMarathi: 'प्रधानमंत्री फसल बीमा योजना',
        description: 'Crop insurance scheme to protect farmers from crop losses',
        descriptionMarathi: 'पीक नुकसानापासून शेतकऱ्यांचे संरक्षण करणारी पीक विमा योजना',
        benefits: ['Premium subsidy up to 90%', 'Coverage for natural disasters', 'Quick claim settlement'],
        eligibility: {
          landSize: 'All farmers',
          farmerType: 'Owner/tenant farmers',
          crops: 'Notified crops only'
        },
        applicationProcess: 'Through banks, insurance companies, or online portal',
        applicationProcessMarathi: 'बँका, विमा कंपन्या किंवा ऑनलाइन पोर्टलद्वारे',
        isActive: true,
        officialUrl: 'https://pmfby.gov.in'
      }
    ];
  }
}

// Singleton instance
export const aiService = new AIService();