import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  Send, 
  Loader2, 
  Camera, 
  Upload, 
  MapPin, 
  Brain,
  Zap,
  AlertCircle,
  CheckCircle,
  Image as ImageIcon
} from 'lucide-react';
import { 
  speechService, 
  ttsService, 
  wakeWordService,
  SpeechRecognitionResult,
  IntentClassificationResult 
} from '@/services/speechService';

export interface EnhancedMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  audioUrl?: string;
  detectedLanguage?: 'mr' | 'en' | 'hi' | 'unknown';
  intent?: string;
  confidence?: number;
  entities?: any;
  imageUrl?: string;
  location?: {
    latitude: number;
    longitude: number;
    accuracy?: number;
  };
  mlPrediction?: {
    type: string;
    result: any;
    confidence: number;
  };
}

interface EnhancedChatInterfaceProps {
  messages: EnhancedMessage[];
  onSendMessage: (data: {
    text: string;
    language?: string;
    intent?: IntentClassificationResult;
    location?: GeolocationPosition;
    image?: File;
  }) => void;
  isLoading?: boolean;
  isListening?: boolean;
  currentLocation?: GeolocationPosition;
}

export default function EnhancedChatInterface({ 
  messages, 
  onSendMessage, 
  isLoading = false,
  isListening = false,
  currentLocation
}: EnhancedChatInterfaceProps) {
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recognitionResult, setRecognitionResult] = useState<SpeechRecognitionResult | null>(null);
  const [intentResult, setIntentResult] = useState<IntentClassificationResult | null>(null);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isProcessingAI, setIsProcessingAI] = useState(false);
  const [locationRequested, setLocationRequested] = useState(false);
  const [currentUserLocation, setCurrentUserLocation] = useState<GeolocationPosition | null>(currentLocation || null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initialize wake word detection
  useEffect(() => {
    if (speechService.isRecognitionSupported()) {
      wakeWordService.startWakeWordDetection(() => {
        console.log('Wake word "Krishi" detected - starting conversation');
        startAdvancedRecording();
      });
    }

    return () => {
      wakeWordService.stopWakeWordDetection();
    };
  }, []);

  const handleTextSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !selectedImage) return;

    setIsProcessingAI(true);
    
    try {
      // Detect language and classify intent for text input
      let language: 'mr' | 'en' | 'hi' | 'unknown' = 'unknown';
      let intent: IntentClassificationResult | undefined;

      if (inputText.trim()) {
        // Simple language detection for text input
        const hasDevanagari = /[\u0900-\u097F]/.test(inputText);
        language = hasDevanagari ? 'mr' : 'en';
        
        // Classify intent
        intent = speechService.classifyIntent(inputText, language);
        console.log('Detected language:', language, 'Intent:', intent);
      }

      // Check if location is needed for the query
      const needsLocation = intent?.intent === 'weather' || intent?.intent === 'market';
      let location = currentUserLocation;
      
      if (needsLocation && !location) {
        location = await requestLocation();
      }

      // Send the enhanced message
      onSendMessage({
        text: inputText,
        language,
        intent,
        location: location || undefined,
        image: selectedImage || undefined
      });

      // Clear inputs
      setInputText('');
      clearSelectedImage();
      setRecognitionResult(null);
      setIntentResult(null);
      
    } catch (error) {
      console.error('Error processing message:', error);
    } finally {
      setIsProcessingAI(false);
    }
  };

  const startAdvancedRecording = async () => {
    if (!speechService.isRecognitionSupported()) {
      alert('Speech recognition not supported in this browser');
      return;
    }

    try {
      setIsRecording(true);
      setIsProcessingAI(true);
      
      console.log('Starting advanced speech recognition...');
      const result = await speechService.startListening();
      
      setRecognitionResult(result);
      
      // Classify intent
      const intent = speechService.classifyIntent(result.transcript, result.detectedLanguage);
      setIntentResult(intent);
      
      // Auto-fill the input with recognized text
      setInputText(result.transcript);
      
      console.log('Speech recognition completed:', result);
      console.log('Intent classification:', intent);
      
    } catch (error) {
      console.error('Speech recognition error:', error);
      alert('Speech recognition failed. Please try again.');
    } finally {
      setIsRecording(false);
      setIsProcessingAI(false);
    }
  };

  const stopRecording = () => {
    if (speechService.getCurrentListeningState()) {
      speechService.stopListening();
      setIsRecording(false);
    }
  };

  const speakText = (text: string, language: 'mr' | 'en' = 'mr') => {
    if (ttsService.isSpeaking()) {
      ttsService.stop();
    }
    ttsService.speak(text, language);
  };

  const handleImageSelection = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearSelectedImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const requestLocation = (): Promise<GeolocationPosition> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation not supported'));
        return;
      }

      setLocationRequested(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentUserLocation(position);
          setLocationRequested(false);
          resolve(position);
        },
        (error) => {
          setLocationRequested(false);
          console.error('Location error:', error);
          reject(error);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000 // 5 minutes
        }
      );
    });
  };

  const formatLocation = (location: GeolocationPosition) => {
    const { latitude, longitude, accuracy } = location.coords;
    return `${latitude.toFixed(6)}, ${longitude.toFixed(6)} (±${Math.round(accuracy || 0)}m)`;
  };

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Wake word indicator */}
      {isListening && (
        <div className="bg-primary/10 border-b border-primary/20 p-2 text-center">
          <div className="flex items-center justify-center gap-2 text-sm text-primary">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
            <Zap className="w-4 h-4" />
            "Krishi" सुनत आहे... (Listening for "Krishi"...)
          </div>
        </div>
      )}

      {/* AI Processing indicator */}
      {isProcessingAI && (
        <div className="bg-blue-50 dark:bg-blue-900/20 border-b border-blue-200 dark:border-blue-800 p-2 text-center">
          <div className="flex items-center justify-center gap-2 text-sm text-blue-600 dark:text-blue-400">
            <Brain className="w-4 h-4 animate-pulse" />
            AI प्रक्रिया सुरू आहे... / AI Processing...
          </div>
        </div>
      )}

      {/* Recognition Result Display */}
      {recognitionResult && (
        <div className="bg-green-50 dark:bg-green-900/20 border-b border-green-200 dark:border-green-800 p-3">
          <div className="flex items-start gap-2">
            <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 mt-0.5" />
            <div className="flex-1">
              <div className="text-sm font-medium text-green-800 dark:text-green-200">
                भाषा ओळखली / Language Detected: 
                <Badge variant="outline" className="ml-2">
                  {recognitionResult.detectedLanguage === 'mr' ? 'मराठी' : recognitionResult.detectedLanguage.toUpperCase()}
                </Badge>
                <Badge variant="outline" className="ml-2">
                  {Math.round(recognitionResult.confidence * 100)}% आत्मविश्वास / Confidence
                </Badge>
              </div>
              {intentResult && (
                <div className="text-sm text-green-700 dark:text-green-300 mt-1">
                  हेतू / Intent: <strong>{intentResult.intent}</strong>
                  {intentResult.entities.crops && (
                    <span className="ml-2">
                      पिके / Crops: {intentResult.entities.crops.join(', ')}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <div className="text-lg font-medium mb-2">नमस्कार! मी कृषी AI सहायक आहे</div>
            <div className="text-sm">Hello! I'm your AI Agricultural Assistant</div>
            <div className="text-xs mt-4 space-y-2">
              <div>"Krishi" बोला किंवा टाईप करा / Say "Krishi" or type to start</div>
              <div className="flex justify-center gap-4 text-xs">
                <span>🌤️ हवामान / Weather</span>
                <span>🌱 रोग / Disease</span>
                <span>📈 बाजार / Market</span>
                <span>💡 सल्ला / Advisory</span>
              </div>
            </div>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
            >
              <Card className={`max-w-xs sm:max-w-sm lg:max-w-md hover-elevate ${
                message.isUser 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-card'
              }`}>
                <CardContent className="p-3">
                  {/* Message content */}
                  <div className="text-sm leading-relaxed">{message.text}</div>
                  
                  {/* AI metadata for user messages */}
                  {message.isUser && (message.detectedLanguage || message.intent) && (
                    <div className="mt-2 pt-2 border-t border-primary-foreground/20">
                      <div className="flex flex-wrap gap-1">
                        {message.detectedLanguage && (
                          <Badge variant="secondary" className="text-xs">
                            {message.detectedLanguage === 'mr' ? '🇮🇳 मराठी' : '🇬🇧 English'}
                          </Badge>
                        )}
                        {message.intent && (
                          <Badge variant="secondary" className="text-xs">
                            📊 {message.intent}
                          </Badge>
                        )}
                        {message.confidence && (
                          <Badge variant="secondary" className="text-xs">
                            ✓ {Math.round(message.confidence * 100)}%
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {/* Image display */}
                  {message.imageUrl && (
                    <div className="mt-2">
                      <img 
                        src={message.imageUrl} 
                        alt="User uploaded image" 
                        className="max-w-full h-auto rounded-md"
                      />
                    </div>
                  )}
                  
                  {/* ML Prediction results */}
                  {message.mlPrediction && (
                    <div className="mt-2 p-2 bg-blue-50 dark:bg-blue-900/20 rounded-md">
                      <div className="text-xs font-medium text-blue-800 dark:text-blue-200">
                        🤖 AI विश्लेषण / AI Analysis: {message.mlPrediction.type}
                      </div>
                      <div className="text-xs text-blue-600 dark:text-blue-300 mt-1">
                        आत्मविश्वास / Confidence: {Math.round(message.mlPrediction.confidence * 100)}%
                      </div>
                    </div>
                  )}
                  
                  {/* Location info */}
                  {message.location && (
                    <div className="mt-2 text-xs text-muted-foreground flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {formatLocation({ coords: message.location } as GeolocationPosition)}
                    </div>
                  )}
                  
                  {/* TTS button for AI responses */}
                  {!message.isUser && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="mt-2 h-6 px-2 text-xs"
                      onClick={() => speakText(message.text, (message.detectedLanguage === 'en' ? 'en' : 'mr'))}
                      data-testid={`button-speak-${message.id}`}
                    >
                      <Volume2 className="w-3 h-3 mr-1" />
                      बोला / Speak
                    </Button>
                  )}
                </CardContent>
              </Card>
            </div>
          ))
        )}
        
        {isLoading && (
          <div className="flex justify-start">
            <Card className="max-w-xs bg-card">
              <CardContent className="p-3 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm text-muted-foreground">
                  AI विचार करत आहे... / AI Thinking...
                </span>
              </CardContent>
            </Card>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Image Preview */}
      {imagePreview && (
        <div className="border-t bg-muted/30 p-3">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img 
                src={imagePreview} 
                alt="Selected image" 
                className="w-16 h-16 object-cover rounded-md"
              />
              <Button
                size="sm"
                variant="destructive"
                className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                onClick={clearSelectedImage}
              >
                ×
              </Button>
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium">चित्र निवडले / Image Selected</div>
              <div className="text-xs text-muted-foreground">
                रोग शोधण्यासाठी / For disease detection
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Location Status */}
      {(locationRequested || currentUserLocation) && (
        <div className="border-t bg-blue-50 dark:bg-blue-900/20 p-2">
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="w-4 h-4" />
            {locationRequested ? (
              <span className="text-blue-600 dark:text-blue-400">
                स्थान मिळवत आहे... / Getting location...
              </span>
            ) : (
              <span className="text-green-600 dark:text-green-400">
                स्थान मिळाले / Location acquired: {formatLocation(currentUserLocation!)}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Input area */}
      <div className="border-t bg-background p-4">
        <form onSubmit={handleTextSubmit} className="space-y-3">
          {/* Input row */}
          <div className="flex gap-2">
            <Input
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="तुमचा प्रश्न लिहा... / Type your question..."
              className="flex-1"
              data-testid="input-message"
              disabled={isRecording || isProcessingAI}
            />
            
            {/* Voice input button */}
            <Button
              type="button"
              size="icon"
              variant={isRecording ? "destructive" : "outline"}
              onClick={isRecording ? stopRecording : startAdvancedRecording}
              data-testid="button-voice"
              disabled={isProcessingAI}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </Button>
            
            {/* Camera input */}
            <Button
              type="button"
              size="icon"
              variant="outline"
              onClick={() => cameraInputRef.current?.click()}
              data-testid="button-camera"
              disabled={isProcessingAI}
            >
              <Camera className="w-4 h-4" />
            </Button>
            
            {/* File upload */}
            <Button
              type="button"
              size="icon"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              data-testid="button-upload"
              disabled={isProcessingAI}
            >
              <Upload className="w-4 h-4" />
            </Button>
            
            {/* Send button */}
            <Button
              type="submit"
              size="icon"
              disabled={(!inputText.trim() && !selectedImage) || isLoading || isProcessingAI}
              data-testid="button-send"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          
          {/* Hidden file inputs */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageSelection}
            className="hidden"
          />
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleImageSelection}
            className="hidden"
          />
        </form>
        
        {/* Help text */}
        <div className="text-xs text-muted-foreground mt-2 text-center">
          🎤 आवाज • 📷 कॅमेरा • 📁 फाइल अपलोड • 📍 स्थान / Voice • Camera • File Upload • Location
        </div>
      </div>
    </div>
  );
}