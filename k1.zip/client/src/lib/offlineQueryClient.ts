import { QueryClient, MutationCache, QueryCache, useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useState, useEffect } from 'react';
import { offlineService } from '../services/offlineService';

// Enhanced query client with offline support
export const createOfflineQueryClient = (): QueryClient => {
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 1000 * 60 * 5, // 5 minutes
        retry: (failureCount, error: any) => {
          // Don't retry if offline
          if (!navigator.onLine) {
            return false;
          }
          // Retry up to 3 times for network errors
          return failureCount < 3;
        },
        refetchOnWindowFocus: false,
        networkMode: 'online',
      },
      mutations: {
        retry: false,
        networkMode: 'online',
      },
    },
    queryCache: new QueryCache({
      onError: (error, query) => {
        console.error('Query error:', error, 'Query key:', query.queryKey);
      },
      onSuccess: (data, query) => {
        // Cache successful queries offline
        if (query.queryKey[0] === '/api/chat/history') {
          const farmerId = query.queryKey[1] as string;
          if (Array.isArray(data)) {
            data.forEach(query => offlineService.saveQuery(query));
          }
        }
      },
    }),
    mutationCache: new MutationCache({
      onError: (error, variables, context, mutation) => {
        console.error('Mutation error:', error);
        
        // If offline, queue the mutation for later sync
        if (!navigator.onLine && mutation.options.mutationKey) {
          const mutationKey = mutation.options.mutationKey as string[];
          const endpoint = mutationKey[0];
          
          offlineService.addPendingMutation({
            method: 'POST',
            url: endpoint,
            body: variables,
          });
        }
      },
      onSuccess: (data, variables, context, mutation) => {
        // Handle successful mutations
        if (mutation.options.mutationKey) {
          const mutationKey = mutation.options.mutationKey as string[];
          const endpoint = mutationKey[0];
          
          // Save to offline storage based on endpoint
          if (endpoint === '/api/chat/message') {
            offlineService.saveQuery(data);
          } else if (endpoint.startsWith('/api/ml/')) {
            offlineService.saveMlPrediction(data);
          } else if (endpoint.startsWith('/api/weather/')) {
            offlineService.saveWeatherData(data);
          }
        }
      },
    }),
  });
};

// Custom hook for offline-aware queries
export const useOfflineQuery = (
  queryKey: any[],
  queryFn: () => Promise<any>,
  options?: any
) => {
  return useQuery({
    queryKey,
    queryFn: async () => {
      // Try online first
      if (navigator.onLine) {
        try {
          return await queryFn();
        } catch (error) {
          console.error('Online query failed, falling back to offline:', error);
        }
      }
      
      // Fallback to offline data
      const [endpoint, ...params] = queryKey;
      
      if (endpoint === '/api/chat/history' && params[0]) {
        const farmerId = params[0] as string;
        const offlineQueries = await offlineService.getQueries(farmerId);
        return offlineQueries.sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      }
      
      if (endpoint === '/api/ml/predictions' && params[0]) {
        const farmerId = params[0] as string;
        const offlinePredictions = await offlineService.getMlPredictions(farmerId);
        return offlinePredictions.sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      }
      
      if (endpoint === '/api/weather/current' && params[0]) {
        const location = params[0] as string;
        const offlineWeatherData = await offlineService.getWeatherData(location);
        return offlineWeatherData.sort((a, b) => 
          new Date(b.date).getTime() - new Date(a.date).getTime()
        );
      }
      
      return [];
    },
    ...options,
  });
};

// Custom hook for offline-aware mutations
export const useOfflineMutation = (
  mutationKey: string[],
  mutationFn: (variables: any) => Promise<any>,
  options?: any
) => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationKey,
    mutationFn: async (variables) => {
      // Try online first
      if (navigator.onLine) {
        try {
          const result = await mutationFn(variables);
          
          // Save successful result to offline storage
          const endpoint = mutationKey[0];
          if (endpoint === '/api/chat/message') {
            await offlineService.saveQuery(result);
          } else if (endpoint.startsWith('/api/ml/')) {
            await offlineService.saveMlPrediction(result);
          } else if (endpoint.startsWith('/api/weather/')) {
            await offlineService.saveWeatherData(result);
          }
          
          return result;
        } catch (error) {
          console.error('Online mutation failed:', error);
          throw error;
        }
      } else {
        // Queue for later sync when offline
        await offlineService.addPendingMutation({
          method: 'POST',
          url: mutationKey[0],
          body: variables,
        });
        
        // Return optimistic result
        const optimisticResult = {
          ...(typeof variables === 'object' && variables !== null ? variables : {}),
          id: `offline_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          createdAt: new Date(),
          synced: 0,
        };
        
        // Save optimistic result to offline storage
        const endpoint = mutationKey[0];
        if (endpoint === '/api/chat/message') {
          await offlineService.saveQuery(optimisticResult);
        } else if (endpoint.startsWith('/api/ml/')) {
          await offlineService.saveMlPrediction(optimisticResult);
        } else if (endpoint.startsWith('/api/weather/')) {
          await offlineService.saveWeatherData(optimisticResult);
        }
        
        return optimisticResult;
      }
    },
    onSuccess: (data, variables, context) => {
      // Invalidate relevant queries to refetch
      const endpoint = mutationKey[0];
      if (endpoint === '/api/chat/message') {
        queryClient.invalidateQueries({ queryKey: ['/api/chat/history'] });
      } else if (endpoint.startsWith('/api/ml/')) {
        queryClient.invalidateQueries({ queryKey: ['/api/ml/predictions'] });
      } else if (endpoint.startsWith('/api/weather/')) {
        queryClient.invalidateQueries({ queryKey: ['/api/weather/current'] });
      }
      
      options?.onSuccess?.(data, variables, context);
    },
    onError: (error, variables, context) => {
      console.error('Mutation failed:', error);
      options?.onError?.(error, variables, context);
    },
    ...options,
  });
};

// Network status hook
export const useNetworkStatus = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      offlineService.sync(); // Trigger sync when back online
    };
    
    const handleOffline = () => {
      setIsOnline(false);
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  
  return { isOnline };
};