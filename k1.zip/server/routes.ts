import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import multer from 'multer';
import { storage } from "./storage";
import { 
  insertFarmerSchema, 
  insertConversationSchema,
  insertQueryHistorySchema,
  insertMlPredictionSchema,
  insertWeatherDataSchema,
  type Farmer,
  type Conversation,
  type QueryHistory,
  type MlPrediction,
  type WeatherData
} from "@shared/schema";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    // Accept only image files
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat and Messaging Routes
  app.post('/api/chat/message', async (req: Request, res: Response) => {
    try {
      const { farmerId, sessionId, message, language, intent, location, imageBase64 } = req.body;
      
      // Create or get chat session
      let session;
      if (sessionId) {
        session = await storage.getChatSession(sessionId);
      } else {
        const sessionData = {
          farmerId,
          messages: [],
          topic: intent?.intent || 'general'
        };
        session = await storage.createChatSession(sessionData);
      }

      // Process the message based on intent
      if (!session) {
        return res.status(500).json({ error: 'Failed to create or retrieve session' });
      }
      
      const queryData = {
        sessionId: session.id,
        farmerId,
        originalQuery: message,
        intent: intent?.intent || 'general',
        response: '', // Will be updated later
        detectedLanguage: language || 'mr',
        confidence: intent?.confidence || 0.0,
        entities: intent?.entities ? JSON.stringify(intent.entities) : null,
        latitude: location?.latitude?.toString(),
        longitude: location?.longitude?.toString(),
        inputType: imageBase64 ? 'voice_and_image' : 'voice'
      };

      const query = await storage.createQuery(queryData);

      // Generate AI response based on intent
      let aiResponse = await generateAIResponse(query, intent, location, imageBase64);
      
      // Update query with AI response
      await storage.updateQueryResponse(query.id, aiResponse.text, JSON.stringify(aiResponse));

      res.json({
        success: true,
        sessionId: session.id,
        queryId: query.id,
        response: aiResponse,
        detectedLanguage: language,
        intent: intent
      });

    } catch (error) {
      console.error('Chat message error:', error);
      res.status(500).json({ 
        error: 'Failed to process message',
        message: 'संदेश प्रक्रिया अयशस्वी / Message processing failed'
      });
    }
  });

  // AI Disease Detection Route
  app.post('/api/ai/disease-detection', upload.single('image'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No image file provided' });
      }

      const { cropName, farmerId, latitude, longitude } = req.body;
      
      // Convert image to base64 for processing
      const imageBase64 = req.file.buffer.toString('base64');
      
      // Mock ML prediction - in production, this would call actual ML models
      const diseaseDetection = await simulateDiseaseDetection(imageBase64, cropName);
      
      // Store ML prediction
      const predictionData = {
        farmerId: farmerId || null,
        modelType: 'disease_detection',
        inputData: JSON.stringify({ 
          cropName, 
          imageHash: imageBase64.substring(0, 50) + '...',
          location: { latitude, longitude }
        }),
        prediction: JSON.stringify(diseaseDetection),
        confidence: diseaseDetection.confidence.toString(),
        timestamp: new Date(),
        modelVersion: 'plant-disease-v1.2',
        processingTime: Math.random() * 2000 + 500 // Mock processing time
      };

      const prediction = await storage.createMLPrediction(predictionData);

      res.json({
        success: true,
        predictionId: prediction.id,
        ...diseaseDetection
      });

    } catch (error) {
      console.error('Disease detection error:', error);
      res.status(500).json({ 
        error: 'Disease detection failed',
        message: 'रोग शोध अयशस्वी / Disease detection failed'
      });
    }
  });

  // Hyperlocal Weather Prediction Route
  app.post('/api/ai/hyperlocal-weather', async (req: Request, res: Response) => {
    try {
      const { latitude, longitude, cropType, predictionDays = 7, farmerId } = req.body;

      if (!latitude || !longitude) {
        return res.status(400).json({ error: 'Location coordinates required' });
      }

      // Mock hyperlocal weather prediction
      const weatherPrediction = await simulateHyperlocalWeather(latitude, longitude, cropType, predictionDays);
      
      // Store ML prediction
      const predictionData = {
        farmerId: farmerId || null,
        modelType: 'hyperlocal_weather',
        inputData: JSON.stringify({ latitude, longitude, cropType, predictionDays }),
        prediction: JSON.stringify(weatherPrediction),
        confidence: weatherPrediction.confidence.toString(),
        timestamp: new Date(),
        modelVersion: 'weather-hyperlocal-v2.1',
        processingTime: Math.random() * 1500 + 300
      };

      const prediction = await storage.createMLPrediction(predictionData);

      res.json({
        success: true,
        predictionId: prediction.id,
        ...weatherPrediction
      });

    } catch (error) {
      console.error('Hyperlocal weather error:', error);
      res.status(500).json({ 
        error: 'Weather prediction failed',
        message: 'हवामान अंदाज अयशस्वी / Weather prediction failed'
      });
    }
  });

  // Market Prediction Route
  app.post('/api/ai/market-prediction', async (req: Request, res: Response) => {
    try {
      const { cropName, latitude, longitude, quantity, farmerId } = req.body;

      if (!cropName || !latitude || !longitude) {
        return res.status(400).json({ error: 'Crop name and location required' });
      }

      // Mock market prediction
      const marketPrediction = await simulateMarketPrediction(cropName, { latitude, longitude }, quantity);
      
      // Store ML prediction
      const predictionData = {
        farmerId: farmerId || null,
        modelType: 'market_prediction',
        inputData: JSON.stringify({ cropName, location: { latitude, longitude }, quantity }),
        prediction: JSON.stringify(marketPrediction),
        confidence: "0.82", // Mock confidence
        timestamp: new Date(),
        modelVersion: 'market-prediction-v1.8',
        processingTime: Math.random() * 1000 + 400
      };

      const prediction = await storage.createMLPrediction(predictionData);

      res.json({
        success: true,
        predictionId: prediction.id,
        ...marketPrediction
      });

    } catch (error) {
      console.error('Market prediction error:', error);
      res.status(500).json({ 
        error: 'Market prediction failed',
        message: 'बाजार अंदाज अयशस्वी / Market prediction failed'
      });
    }
  });

  // Crop Health Analysis Route
  app.post('/api/ai/crop-health', async (req: Request, res: Response) => {
    try {
      const { cropType, farmerId, latitude, longitude, currentStage, issues } = req.body;

      if (!cropType) {
        return res.status(400).json({ error: 'Crop type required' });
      }

      // Mock crop health analysis
      const cropHealth = await simulateCropHealthAnalysis(cropType, currentStage, issues);
      
      // Store ML prediction
      const predictionData = {
        farmerId: farmerId || null,
        modelType: 'crop_health',
        inputData: JSON.stringify({ cropType, currentStage, issues, location: { latitude, longitude } }),
        prediction: JSON.stringify(cropHealth),
        confidence: cropHealth.expectedYield.confidence.toString(),
        timestamp: new Date(),
        modelVersion: 'crop-health-v1.5',
        processingTime: Math.random() * 1800 + 600
      };

      const prediction = await storage.createMLPrediction(predictionData);

      res.json({
        success: true,
        predictionId: prediction.id,
        ...cropHealth
      });

    } catch (error) {
      console.error('Crop health analysis error:', error);
      res.status(500).json({ 
        error: 'Crop health analysis failed',
        message: 'पीक आरोग्य विश्लेषण अयशस्वी / Crop health analysis failed'
      });
    }
  });

  // Government Schemes Route
  app.get('/api/ai/government-schemes', async (req: Request, res: Response) => {
    try {
      const { cropType, farmSize, location, schemeType } = req.query;

      // Mock government schemes data
      const schemes = await getGovernmentSchemes({ 
        cropType: cropType as string,
        farmSize: farmSize as string,
        location: location as string,
        schemeType: schemeType as string
      });

      res.json({
        success: true,
        schemes,
        lastUpdated: new Date().toISOString()
      });

    } catch (error) {
      console.error('Government schemes error:', error);
      res.status(500).json({ 
        error: 'Failed to fetch government schemes',
        message: 'सरकारी योजना मिळवणे अयशस्वी / Failed to fetch government schemes'
      });
    }
  });

  // Farmer Profile Routes
  app.post('/api/farmers', async (req: Request, res: Response) => {
    try {
      const farmerData = insertFarmerSchema.parse(req.body);
      const farmer = await storage.createFarmer(farmerData);
      res.json({ success: true, farmer });
    } catch (error) {
      console.error('Create farmer error:', error);
      res.status(400).json({ error: 'Invalid farmer data' });
    }
  });

  app.get('/api/farmers/:id', async (req: Request, res: Response) => {
    try {
      const farmer = await storage.getFarmer(req.params.id);
      if (!farmer) {
        return res.status(404).json({ error: 'Farmer not found' });
      }
      res.json({ success: true, farmer });
    } catch (error) {
      console.error('Get farmer error:', error);
      res.status(500).json({ error: 'Failed to get farmer' });
    }
  });

  app.put('/api/farmers/:id', async (req: Request, res: Response) => {
    try {
      const farmer = await storage.updateFarmer(req.params.id, req.body);
      res.json({ success: true, farmer });
    } catch (error) {
      console.error('Update farmer error:', error);
      res.status(500).json({ error: 'Failed to update farmer' });
    }
  });

  // Chat Session Routes
  app.get('/api/chat/sessions/:farmerId', async (req: Request, res: Response) => {
    try {
      const sessions = await storage.getFarmerChatSessions(req.params.farmerId);
      res.json({ success: true, sessions });
    } catch (error) {
      console.error('Get chat sessions error:', error);
      res.status(500).json({ error: 'Failed to get chat sessions' });
    }
  });

  // Query History Routes
  app.get('/api/queries/:sessionId', async (req: Request, res: Response) => {
    try {
      const queries = await storage.getSessionQueries(req.params.sessionId);
      res.json({ success: true, queries });
    } catch (error) {
      console.error('Get queries error:', error);
      res.status(500).json({ error: 'Failed to get queries' });
    }
  });

  // ML Predictions History Routes
  app.get('/api/predictions/:farmerId', async (req: Request, res: Response) => {
    try {
      const predictions = await storage.getFarmerPredictions(req.params.farmerId);
      res.json({ success: true, predictions });
    } catch (error) {
      console.error('Get predictions error:', error);
      res.status(500).json({ error: 'Failed to get predictions' });
    }
  });

  // Location Data Routes
  app.post('/api/location', async (req: Request, res: Response) => {
    try {
      const locationData = insertWeatherDataSchema.parse(req.body);
      const location = await storage.saveLocationData(locationData);
      res.json({ success: true, location });
    } catch (error) {
      console.error('Save location error:', error);
      res.status(500).json({ error: 'Failed to save location' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Mock AI Response Generation Functions
async function generateAIResponse(query: any, intent: any, location: any, imageBase64?: string): Promise<any> {
  const intentType = intent?.intent || 'general';
  
  switch (intentType) {
    case 'weather':
      return {
        text: `आज हवामान ${location ? `${location.latitude.toFixed(2)}, ${location.longitude.toFixed(2)}` : 'तुमच्या भागात'} चांगले आहे. तापमान ३२°C, आर्द्रता ६५%. सिंचनाची गरज नाही. / Today's weather is good${location ? ` at ${location.latitude.toFixed(2)}, ${location.longitude.toFixed(2)}` : ' in your area'}. Temperature 32°C, humidity 65%. No irrigation needed.`,
        confidence: 0.92,
        type: 'weather',
        data: { temperature: 32, humidity: 65, recommendation: 'no_irrigation_needed' }
      };
    
    case 'disease':
      return {
        text: imageBase64 
          ? `चित्राचे विश्लेषण केले. तुमच्या पिकावर अर्ली ब्लाइट रोगाची चिन्हे दिसत आहेत. कॉपर सल्फेट फवारणी करा. / Image analyzed. Signs of early blight disease detected on your crop. Apply copper sulfate spray.`
          : `पिक रोगाबद्दल काय जाणून घ्यायचे आहे? चित्र अपलोड करा किंवा लक्षणे सांगा. / What would you like to know about crop diseases? Upload an image or describe symptoms.`,
        confidence: imageBase64 ? 0.87 : 0.95,
        type: 'disease',
        data: imageBase64 ? { diseaseDetected: 'early_blight', confidence: 0.87 } : null
      };
    
    case 'market':
      return {
        text: `आजचे बाजार भाव: टोमेटो ₹40/किलो, कांदा ₹25/किलो. जालना APMC मध्ये चांगले दर मिळतील. / Today's market rates: Tomato ₹40/kg, Onion ₹25/kg. Good rates available at Jalna APMC.`,
        confidence: 0.89,
        type: 'market',
        data: { tomato: 40, onion: 25, recommendedMarket: 'Jalna APMC' }
      };
    
    default:
      return {
        text: `मी तुमची कृषी सहायक आहे. हवामान, रोग, बाजार भाव याबद्दल विचारू शकता. / I am your agricultural assistant. You can ask about weather, diseases, market rates.`,
        confidence: 0.95,
        type: 'general',
        data: null
      };
  }
}

// Mock ML Model Simulation Functions
async function simulateDiseaseDetection(imageBase64: string, cropName?: string): Promise<any> {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
  
  return {
    detectedDiseases: [
      {
        name: 'Early Blight',
        nameMarathi: 'पूर्व अंगारा रोग',
        confidence: 0.87,
        severity: 'medium',
        description: 'Fungal disease affecting leaves with brown spots and yellowing',
        descriptionMarathi: 'पानांवर तपकिरी डाग आणि पिवळेपणा असलेला बुरशीजन्य रोग'
      }
    ],
    recommendedTreatment: [
      {
        treatment: 'Apply copper sulfate fungicide spray',
        treatmentMarathi: 'कॉपर सल्फेट बुरशीनाशक फवारणी करा',
        urgency: 'within_week',
        cost: '₹150-200 per acre',
        availability: 'Available at local agricultural stores'
      }
    ],
    overallHealthScore: 0.72,
    confidence: 0.84
  };
}

async function simulateHyperlocalWeather(latitude: number, longitude: number, cropType?: string, days = 7): Promise<any> {
  await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 1200));
  
  return {
    hyperLocalForecast: Array.from({ length: days }, (_, i) => ({
      date: new Date(Date.now() + i * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      temperature: { min: 18 + Math.random() * 5, max: 30 + Math.random() * 8, avg: 25 + Math.random() * 5 },
      rainfall: { probability: Math.random() * 0.8, amount: Math.random() * 10 },
      humidity: 50 + Math.random() * 30,
      windSpeed: 5 + Math.random() * 15,
      conditions: ['Clear', 'Partly Cloudy', 'Cloudy', 'Light Rain'][Math.floor(Math.random() * 4)],
      conditionsMarathi: ['साफ', 'अंशतः ढगाळ', 'ढगाळ', 'हलका पाऊस'][Math.floor(Math.random() * 4)]
    })),
    agriculturalAdvisory: {
      irrigation: 'Light irrigation recommended in evening',
      irrigationMarathi: 'संध्याकाळी हलकी सिंचन करा',
      planting: 'Good conditions for sowing winter crops',
      plantingMarathi: 'हिवाळी पिकांच्या पेरणीसाठी योग्य परिस्थिती'
    },
    alerts: [],
    confidence: 0.89
  };
}

async function simulateMarketPrediction(cropName: string, location: any, quantity?: number): Promise<any> {
  await new Promise(resolve => setTimeout(resolve, 600 + Math.random() * 1000));
  
  const basePrice = { 'tomato': 40, 'onion': 25, 'potato': 18, 'wheat': 2100 }[cropName.toLowerCase()] || 30;
  
  return {
    currentPrices: [
      {
        market: 'Jalna APMC',
        price: basePrice + Math.random() * 10 - 5,
        unit: cropName.toLowerCase() === 'wheat' ? 'Quintal' : 'Kg',
        date: new Date().toISOString().split('T')[0],
        trend: ['up', 'down', 'stable'][Math.floor(Math.random() * 3)]
      }
    ],
    predictions: [
      {
        period: '7d',
        predictedPrice: basePrice * (1 + (Math.random() * 0.2 - 0.1)),
        confidence: 0.78,
        factors: ['Seasonal demand', 'Weather conditions', 'Transport costs']
      }
    ],
    recommendations: {
      bestTimeToSell: 'Next week',
      bestMarkets: ['Jalna APMC', 'Aurangabad APMC'],
      priceOptimizationTips: ['Grade your produce properly', 'Monitor daily trends'],
      priceOptimizationTipsMarathi: ['उत्पादनाची योग्य गुणवत्ता करा', 'दैनंदिन ट्रेंडचे निरीक्षण करा']
    }
  };
}

async function simulateCropHealthAnalysis(cropType: string, stage?: string, issues?: string[]): Promise<any> {
  await new Promise(resolve => setTimeout(resolve, 1200 + Math.random() * 1500));
  
  return {
    healthScore: 0.7 + Math.random() * 0.25,
    recommendations: [
      {
        category: 'fertilizer',
        recommendation: 'Apply NPK fertilizer (19:19:19) at 50kg per acre',
        recommendationMarathi: 'एनपीके खत (19:19:19) 50 किलो प्रति एकर वापरा',
        priority: 'high',
        timeline: 'Within 3 days',
        estimatedCost: '₹800-1000'
      }
    ],
    nutritionAnalysis: {
      nitrogen: 'deficient',
      phosphorus: 'sufficient',
      potassium: 'deficient'
    },
    expectedYield: {
      predicted: 10 + Math.random() * 8,
      unit: 'Quintal per acre',
      confidence: 0.82,
      factors: ['Current health status', 'Weather predictions', 'Nutrition levels']
    }
  };
}

async function getGovernmentSchemes(params: any): Promise<any[]> {
  return [
    {
      id: '1',
      title: 'PM-KISAN Scheme',
      titleMarathi: 'पीएम-किसान योजना',
      description: 'Income support of ₹6000 per year to small and marginal farmers',
      descriptionMarathi: 'लहान आणि सीमांत शेतकऱ्यांना वर्षाला ₹6000 उत्पन्न आधार',
      eligibility: { landSize: 'Up to 2 hectares', farmerType: 'Small and marginal farmers' },
      isActive: true
    }
  ];
}