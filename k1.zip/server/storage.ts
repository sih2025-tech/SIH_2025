import { 
  type User, 
  type InsertUser,
  type Farmer,
  type InsertFarmer,
  type Conversation,
  type InsertConversation,
  type QueryHistory,
  type InsertQueryHistory,
  type MlPrediction,
  type InsertMlPrediction,
  type WeatherData,
  type InsertWeatherData,
  type DiseaseDetection,
  type InsertDiseaseDetection
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Legacy user operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Farmer operations
  createFarmer(farmer: InsertFarmer): Promise<Farmer>;
  getFarmer(id: string): Promise<Farmer | undefined>;
  updateFarmer(id: string, updates: Partial<InsertFarmer>): Promise<Farmer>;
  getFarmerByPhone(phone: string): Promise<Farmer | undefined>;
  
  // Chat session operations (using Conversation)
  createChatSession(session: InsertConversation): Promise<Conversation>;
  getChatSession(id: string): Promise<Conversation | undefined>;
  updateChatSession(id: string, updates: Partial<InsertConversation>): Promise<Conversation>;
  getFarmerChatSessions(farmerId: string): Promise<Conversation[]>;
  
  // Query operations
  createQuery(query: InsertQueryHistory): Promise<QueryHistory>;
  getQuery(id: string): Promise<QueryHistory | undefined>;
  updateQueryResponse(id: string, response: string, fullResponse: string): Promise<QueryHistory>;
  getSessionQueries(sessionId: string): Promise<QueryHistory[]>;
  getFarmerQueries(farmerId: string): Promise<QueryHistory[]>;
  
  // ML Prediction operations
  createMLPrediction(prediction: InsertMlPrediction): Promise<MlPrediction>;
  getMLPrediction(id: string): Promise<MlPrediction | undefined>;
  getFarmerPredictions(farmerId: string): Promise<MlPrediction[]>;
  getPredictionsByType(modelType: string): Promise<MlPrediction[]>;
  
  // Location/Weather data operations
  saveLocationData(locationData: InsertWeatherData): Promise<WeatherData>;
  getLocationData(latitude: number, longitude: number, maxAge?: number): Promise<WeatherData | undefined>;
  getRecentWeatherData(limit?: number): Promise<WeatherData[]>;
  
  // Disease detection operations
  createDiseaseDetection(detection: InsertDiseaseDetection): Promise<DiseaseDetection>;
  getDiseaseDetection(id: string): Promise<DiseaseDetection | undefined>;
  getFarmerDiseaseDetections(farmerId: string): Promise<DiseaseDetection[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private farmers: Map<string, Farmer>;
  private conversations: Map<string, Conversation>;
  private queries: Map<string, QueryHistory>;
  private mlPredictions: Map<string, MlPrediction>;
  private weatherData: Map<string, WeatherData>;
  private diseaseDetections: Map<string, DiseaseDetection>;

  constructor() {
    this.users = new Map();
    this.farmers = new Map();
    this.conversations = new Map();
    this.queries = new Map();
    this.mlPredictions = new Map();
    this.weatherData = new Map();
    this.diseaseDetections = new Map();
  }

  // Legacy user operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Farmer operations
  async createFarmer(insertFarmer: InsertFarmer): Promise<Farmer> {
    const id = randomUUID();
    const now = new Date();
    const farmer: Farmer = { 
      ...insertFarmer,
      location: insertFarmer.location ?? null,
      phone: insertFarmer.phone ?? null,
      farmSize: insertFarmer.farmSize ?? null,
      preferredLanguage: insertFarmer.preferredLanguage ?? null,
      latitude: insertFarmer.latitude ?? null,
      longitude: insertFarmer.longitude ?? null,
      gpsAccuracy: insertFarmer.gpsAccuracy ?? null,
      lastLocationUpdate: insertFarmer.lastLocationUpdate ?? null,
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.farmers.set(id, farmer);
    return farmer;
  }

  async getFarmer(id: string): Promise<Farmer | undefined> {
    return this.farmers.get(id);
  }

  async updateFarmer(id: string, updates: Partial<InsertFarmer>): Promise<Farmer> {
    const existing = this.farmers.get(id);
    if (!existing) {
      throw new Error(`Farmer with id ${id} not found`);
    }
    
    const updated: Farmer = {
      ...existing,
      ...updates,
      updatedAt: new Date()
    };
    this.farmers.set(id, updated);
    return updated;
  }

  async getFarmerByPhone(phone: string): Promise<Farmer | undefined> {
    return Array.from(this.farmers.values()).find(
      (farmer) => farmer.phone === phone
    );
  }

  // Chat session operations
  async createChatSession(insertConversation: InsertConversation): Promise<Conversation> {
    const id = randomUUID();
    const now = new Date();
    const conversation: Conversation = {
      ...insertConversation,
      topic: insertConversation.topic ?? null,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async getChatSession(id: string): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async updateChatSession(id: string, updates: Partial<InsertConversation>): Promise<Conversation> {
    const existing = this.conversations.get(id);
    if (!existing) {
      throw new Error(`Conversation with id ${id} not found`);
    }
    
    const updated: Conversation = {
      ...existing,
      ...updates,
      updatedAt: new Date()
    };
    this.conversations.set(id, updated);
    return updated;
  }

  async getFarmerChatSessions(farmerId: string): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      (conversation) => conversation.farmerId === farmerId
    );
  }

  // Query operations
  async createQuery(insertQuery: InsertQueryHistory): Promise<QueryHistory> {
    const id = randomUUID();
    const now = new Date();
    const query: QueryHistory = {
      ...insertQuery,
      sessionId: insertQuery.sessionId ?? null,
      latitude: insertQuery.latitude ?? null,
      longitude: insertQuery.longitude ?? null,
      detectedLanguage: insertQuery.detectedLanguage ?? null,
      entities: insertQuery.entities ?? null,
      confidence: insertQuery.confidence ?? null,
      satisfied: insertQuery.satisfied ?? null,
      transcribedText: insertQuery.transcribedText ?? null,
      id,
      createdAt: now
    };
    this.queries.set(id, query);
    return query;
  }

  async getQuery(id: string): Promise<QueryHistory | undefined> {
    return this.queries.get(id);
  }

  async updateQueryResponse(id: string, response: string, fullResponse: string): Promise<QueryHistory> {
    const existing = this.queries.get(id);
    if (!existing) {
      throw new Error(`Query with id ${id} not found`);
    }
    
    const updated: QueryHistory = {
      ...existing,
      response: response
    };
    this.queries.set(id, updated);
    return updated;
  }

  async getSessionQueries(sessionId: string): Promise<QueryHistory[]> {
    return Array.from(this.queries.values()).filter(
      (query) => query.sessionId === sessionId
    );
  }

  async getFarmerQueries(farmerId: string): Promise<QueryHistory[]> {
    return Array.from(this.queries.values()).filter(
      (query) => query.farmerId === farmerId
    );
  }

  // ML Prediction operations
  async createMLPrediction(insertPrediction: InsertMlPrediction): Promise<MlPrediction> {
    const id = randomUUID();
    const now = new Date();
    const prediction: MlPrediction = {
      ...insertPrediction,
      status: insertPrediction.status ?? null,
      confidence: insertPrediction.confidence ?? null,
      modelVersion: insertPrediction.modelVersion ?? null,
      processingTime: insertPrediction.processingTime ?? null,
      errorMessage: insertPrediction.errorMessage ?? null,
      id,
      createdAt: now
    };
    this.mlPredictions.set(id, prediction);
    return prediction;
  }

  async getMLPrediction(id: string): Promise<MlPrediction | undefined> {
    return this.mlPredictions.get(id);
  }

  async getFarmerPredictions(farmerId: string): Promise<MlPrediction[]> {
    return Array.from(this.mlPredictions.values()).filter(
      (prediction) => prediction.farmerId === farmerId
    );
  }

  async getPredictionsByType(modelType: string): Promise<MlPrediction[]> {
    return Array.from(this.mlPredictions.values()).filter(
      (prediction) => prediction.modelType === modelType
    );
  }

  // Location/Weather data operations
  async saveLocationData(insertWeatherData: InsertWeatherData): Promise<WeatherData> {
    const id = randomUUID();
    const weatherData: WeatherData = {
      ...insertWeatherData,
      latitude: insertWeatherData.latitude ?? null,
      longitude: insertWeatherData.longitude ?? null,
      temperature: insertWeatherData.temperature ?? null,
      humidity: insertWeatherData.humidity ?? null,
      rainfall: insertWeatherData.rainfall ?? null,
      windSpeed: insertWeatherData.windSpeed ?? null,
      forecast: insertWeatherData.forecast ?? null,
      alerts: insertWeatherData.alerts ?? null,
      source: insertWeatherData.source ?? null,
      airQuality: insertWeatherData.airQuality ?? null,
      visibility: insertWeatherData.visibility ?? null,
      pressure: insertWeatherData.pressure ?? null,
      uvIndex: insertWeatherData.uvIndex ?? null,
      cloudCover: insertWeatherData.cloudCover ?? null,
      fogConditions: insertWeatherData.fogConditions ?? null,
      id
    };
    this.weatherData.set(id, weatherData);
    return weatherData;
  }

  async getLocationData(latitude: number, longitude: number, maxAge = 3600000): Promise<WeatherData | undefined> {
    // Find weather data within 0.01 degrees (roughly 1km) and within maxAge milliseconds
    const cutoffTime = new Date(Date.now() - maxAge);
    
    return Array.from(this.weatherData.values()).find((data) => {
      if (!data.latitude || !data.longitude || !data.date) return false;
      
      const latDiff = Math.abs(parseFloat(data.latitude) - latitude);
      const lonDiff = Math.abs(parseFloat(data.longitude) - longitude);
      const isNearby = latDiff <= 0.01 && lonDiff <= 0.01;
      const isRecent = data.date >= cutoffTime;
      
      return isNearby && isRecent;
    });
  }

  async getRecentWeatherData(limit = 50): Promise<WeatherData[]> {
    return Array.from(this.weatherData.values())
      .sort((a, b) => {
        if (!a.date || !b.date) return 0;
        return b.date.getTime() - a.date.getTime();
      })
      .slice(0, limit);
  }

  // Disease detection operations
  async createDiseaseDetection(insertDetection: InsertDiseaseDetection): Promise<DiseaseDetection> {
    const id = randomUUID();
    const now = new Date();
    const detection: DiseaseDetection = {
      ...insertDetection,
      imageUrl: insertDetection.imageUrl ?? null,
      imageThumbnail: insertDetection.imageThumbnail ?? null,
      recommendedTreatment: insertDetection.recommendedTreatment ?? null,
      severity: insertDetection.severity ?? null,
      confidence: insertDetection.confidence ?? null,
      modelVersion: insertDetection.modelVersion ?? null,
      verified: insertDetection.verified ?? null,
      verifiedBy: insertDetection.verifiedBy ?? null,
      notes: insertDetection.notes ?? null,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.diseaseDetections.set(id, detection);
    return detection;
  }

  async getDiseaseDetection(id: string): Promise<DiseaseDetection | undefined> {
    return this.diseaseDetections.get(id);
  }

  async getFarmerDiseaseDetections(farmerId: string): Promise<DiseaseDetection[]> {
    return Array.from(this.diseaseDetections.values()).filter(
      (detection) => detection.farmerId === farmerId
    );
  }
}

export const storage = new MemStorage();
